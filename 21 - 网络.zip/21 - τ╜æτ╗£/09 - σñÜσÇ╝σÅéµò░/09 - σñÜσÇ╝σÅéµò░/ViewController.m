//
//  ViewController.m
//  09 - 多值参数
//
//  Created by 孙虎林 on 15/8/6.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}


/**
 *  多值参数
 */
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSString *urlStr = [@"http://localhost:8080/MJServer/weather" stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    NSURL *url = [NSURL URLWithString:urlStr];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    request.HTTPMethod = @"POST";
    request.timeoutInterval = 5.0;
    
    /**
     *  多值参数
     *  本质上还是发送请求参数给服务器，设置请求体
     *  天气 ：北京，无锡，沭阳。。
     */
    NSMutableString *parame = [NSMutableString string];
    [parame appendString:@"place=beijing"];
    [parame appendString:@"&place=wuxi"];
    [parame appendString:@"&place=shuyang"];
    
    request.HTTPBody =[parame dataUsingEncoding:NSUTF8StringEncoding];
    
    [request setValue:@"iPhone 6+" forHTTPHeaderField:@"User-Agent"];
    
    // 发送请求
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
        if (connectionError ||data == nil) {
            NSLog(@"请求失败");
            return ;
        }
        
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        NSString *error = dict[@"error"];
        if (error) {
            NSLog(@"error");
        } else {
            NSLog(@"%@-", dict);
        }
    }];
}

@end
