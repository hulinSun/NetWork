//
//  ViewController.m
//  03 - URLConnection 异步请求（代理方式）
//
//  Created by 孙虎林 on 15/8/4.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"

@interface ViewController () <NSURLConnectionDataDelegate>

@property(nonatomic,strong)NSData *data;
@end

@implementation ViewController

-(NSData *)data
{
    if (!_data) {
        _data = [[NSData alloc]init];
    }
    return _data;
}

- (void)viewDidLoad {
    [super viewDidLoad];
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self connectionAsyncDelegte];
}

/**
 *  connection 发送异步请求，通过代理的方式获得数据
 */
-(void)connectionAsyncDelegte
{
    // 1.url字符串 转码操作
    NSString *urlStr = [@"http://localhost:8080/MJServer/login?username=123&pwd=13" stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    // 2.创建请求对象
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:urlStr]];
    
    // 发送请求 :类方法
    [NSURLConnection connectionWithRequest:request delegate:self];
    
    
//      NSURLConnection *conn = [[NSURLConnection alloc]initWithRequest:request delegate:self]; //有返回值,但是自动开启用不到，只有当startImmediately:NO 才需要拿到实例变量手动开启
    
//    NSURLConnection *conn = [[NSURLConnection alloc]initWithRequest:request delegate:self startImmediately:NO];
//    [conn start];  // 如果，startImmediately:NO，不是马上开启的话，那么就需要手动start，其他两种不需要，自定开始发送请求
}



/** 发送异步网络请求之后，请求失败之后会调用(请求超时，没有网络)  */
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSLog(@"请求失败");
}

/** 开始收到服务器的响应时候调用*/
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    // response 里面有很多信息，状态码。请求头
    NSLog(@"didReceiveResponse--%@-%@",response,[NSThread currentThread]);
}
/** 受到服务器返回的数据时候调用(如果数据很大的话，这个方法会调用多次，一般都在这个方法里面拼接data)  */
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    self.data = data;
     NSLog(@"didReceiveData---%ld",data.length);
}
/** 请求结束的时候调用 (一般再这个方法里面 做一些数据的处理) */
-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    // connection 里面也有很多信息，有请求路径
     NSLog(@"connectionDidFinishLoading---%@++++%@",connection,[NSThread currentThread]);
    
    // 解析data
    if (self.data) { // 要先判断，切记
        NSError *err = nil;
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:self.data options:NSJSONReadingMutableLeaves error:&err]; // & 
        if (err) { // 严谨写法,解析错误
            NSLog(@"解析错误");
        }else{
            NSLog(@"解析结果: %@---%@",dict[@"error"],dict.allKeys[0]);
        }
    }
}

@end
