//
//  ViewController.m
//  05 - 土狗视频（XML 解析）
//
//  Created by 孙虎林 on 15/8/4.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"
#import "JNVideo.h"
#import "JNVideoCell.h"
#import <MediaPlayer/MediaPlayer.h>
#import "GDataXMLNode.h"

#define JNVideoUrl(path)  [NSURL URLWithString:[NSString stringWithFormat:@"http://localhost:8080/MJServer/%@",path]]

@interface ViewController () <NSXMLParserDelegate>
@property(nonatomic,strong)NSArray *videos;

@property(nonatomic,strong)NSMutableArray *tempArray;
@end

@implementation ViewController

-(NSMutableArray *)tempArray
{
    if (!_tempArray) {
        _tempArray = [[NSMutableArray alloc]init];
    }
    return _tempArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tableView.rowHeight = 60;
    
    
#warning 注意，url ？后面跟上参数，参数之间不能留空格,指定返回数据的类型(JSON XML 都要大写)
    NSURL *url = [NSURL URLWithString:@"http://localhost:8080/MJServer/video?type=XML"];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    // 发送网络请求
    NSOperationQueue *queue = [NSOperationQueue mainQueue];
    
    [NSURLConnection sendAsynchronousRequest:request queue:queue completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
        
        // 如果有错误，并且没有数据，那么直接返回
        if (connectionError || data == nil) return;
        if (data) {
            //1.创建解析器
            NSXMLParser *parser = [[NSXMLParser alloc]initWithData:data];
            //2.设置代理: 把解析的结果告诉代理，实际上是代理监听解析的风吹草动
            parser.delegate = self;
            //3.开始解析(事件驱动)
            [parser parse]; // （同步执行:再主线程中执行，所以不能搞太大的文件，不然会阻塞主线程）
        }
        
        [self.tableView reloadData];
    }];
}

/** JSON 解析
 // 解析
 if (data) {
 NSError *err = nil;
 NSDictionary *dataDict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&err];
 if (err) {
 NSLog(@"解析失败");
 }else{ // 成功解析
 NSArray *dictArr = dataDict[@"videos"];
 NSMutableArray *tempArr = [NSMutableArray array];
 for (NSDictionary *dict in dictArr) {
 JNVideo *video = [JNVideo videoWithDict:dict];
 [tempArr addObject:video];
 }
 self.videos = tempArr;
 [self.tableView reloadData];
 }
 }
 */

/** Dom 解析：适合小文件，一口气吞进来
 if (data) { // Dom 解析
 //  获取整个XML文档 (dom==》document)
 GDataXMLDocument *doc = [[GDataXMLDocument alloc]initWithData:data options:0 error:nil];
 
 // 获取根元素-- videos
 GDataXMLElement *rootElem = [doc rootElement];
 // 获取子元素 video
 NSArray *elements = [rootElem elementsForName:@"video"];
 
 NSMutableArray *tempArray = [NSMutableArray array];
 // 获取子元素的属性，赋值给模型
 for (GDataXMLElement *element in elements) {
 JNVideo *video = [[JNVideo alloc]init];
 video.ID = [element attributeForName:@"id"].stringValue.intValue;
 video.name = [element attributeForName:@"name"].stringValue;
 video.image = [element attributeForName:@"image"].stringValue;
 video.url = [element attributeForName:@"url"].stringValue;
 video.length = [element attributeForName:@"length"].stringValue.intValue;
 [tempArray addObject:video];
 }
 self.videos = tempArray;
 }
 */

/**
 设置libxml2的头文件搜索路径（为了能找到libxml2库的所有头文件）
 在Head Search Path中加入/usr/include/libxml2
 
 设置链接参数（自动链接libxml2库）
 在Other Linker Flags中加入-lxml2
 
 build pharhse -->Gdatxml: -fno-objc-arc // 取消arc环境
 */

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.videos.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    JNVideoCell *cell = [JNVideoCell cellWithTableView:tableView];
    
    cell.video = self.videos[indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // 取出模型
    JNVideo *video = self.videos[indexPath.row];
    
#warning 播放器
    // 播放器
    NSURL *url = JNVideoUrl(video.url); // 宏的巧妙引用
    
    MPMoviePlayerViewController *playVC = [[MPMoviePlayerViewController alloc]initWithContentURL:url];
    [self presentViewController:playVC animated:YES completion:nil];
    
}



#pragma mark - NSXMLParserDelegate
/** 开始解析到文档的时候调用 ：解析开始 */
- (void)parserDidStartDocument:(NSXMLParser *)parser
{
//    NSLog(@"parserDidStartDocument");
}


/**
 *  开始解析到元素的时候调用
 *
 *  @param parser        解析器对象
 *  @param elementName   元素的名称(这一节点元素的名称)
 *  @param attributeDict 属性字典 (这一节点内属性的 字典,注意，只是解析到的当前节点内的字典)
 */
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
//     NSLog(@"didStartElement-elementName:%@",elementName);
    
    // 因为节点有多个，所以要判断一下，只需要解析模型对应的节点
    if ([elementName isEqualToString:@"videos"]) return; // 直接返回。不需要创建video 模型
    
    // 能来到这里那么就是video 对应的节点
    JNVideo *video = [JNVideo videoWithDict:attributeDict];
    
    [self.tempArray addObject:video];
    
}
/** 结束解析到元素的时候调用 */
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
//    NSLog(@"didEndElement-elementName:%@",elementName);
}


/** 结束解析到文档的时候调用 ：解析结束 */
-(void)parserDidEndDocument:(NSXMLParser *)parser
{
//    NSLog(@"parserDidEndDocument");
    self.videos = self.tempArray;
}
@end
