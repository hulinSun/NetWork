//
//  ViewController.m
//  17 - NSURLSession 断点下载
//
//  Created by 孙虎林 on 15/8/7.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"

@interface ViewController () <NSURLSessionDownloadDelegate> // 下载的代理方法
- (IBAction)btnClick:(id)sender;
@property (weak, nonatomic) IBOutlet UIProgressView *progressView;

@property(nonatomic,strong)NSURLSessionDownloadTask *task;
/**
 *  恢复下载的数据
 */
@property(nonatomic,strong)NSData *resumeData ;

/**
 *  搞个懒加载
 */
@property(nonatomic,strong)NSURLSession *session;

@end

@implementation ViewController

-(NSURLSession *)session
{
    if (!_session) {
        // 配置对象：结合代理使用
        NSURLSessionConfiguration *cfg = [NSURLSessionConfiguration defaultSessionConfiguration];
        
        // 最好放在主队列 ,存放代理方法的任务(setter 方法，不会造成循环应用)
#warning 注意，如果有compliaHandle 的block 的话，那么不会调用代理方法，会调用block
        self.session = [NSURLSession sessionWithConfiguration:cfg delegate:self delegateQueue:[NSOperationQueue mainQueue]];
    }
    return _session;
}

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (IBAction)btnClick:(UIButton *)btn {
    btn.selected = !btn.isSelected;
    
    if (self.task == nil) { // 没有任务，那么开始下载，但是要判断是开始还是继续
        if (self.resumeData) { // 有值，那么应该继续下载
            [self resumeDownload];
        }else{ // 开始下载
            [self start];
        }
    }else{ // 暂停
        [self pause];
    }
}

/**
 *  开始下载
 */
-(void)start
{
    NSURL *url = [NSURL URLWithString:@"http://localhost:8080/MJServer/resources/aa.zip"];
    NSURLSessionDownloadTask *task = [self.session downloadTaskWithURL:url];
    self.task = task;
    // 开始下载
    [task resume];
}

/**
 *  恢复下载(继续下载)
 */
-(void)resumeDownload
{
    // 恢复下载: 利用 resumeData 来重新创建任务
    self.task = [self.session downloadTaskWithResumeData:self.resumeData];
    // 开始
    [self.task resume];
    // 清空，起到保存下一次开始位置url 的效果
    self.resumeData = nil; // 一定要清空
}

/**
 *  暂停下载
 */
-(void)pause
{
    // 暂停
    __weak typeof(self) weakSelf = self;
    [self.task cancelByProducingResumeData:^(NSData *resumeData) {
        // 保存数据 resumeData里面保存着下次从哪里开始下载的字节，和下载的url数据，所以要保存一下
        weakSelf.resumeData = resumeData;
        weakSelf.task = nil; // 暂停，清空任务
    }];
}


#pragma mark - NSURLSessionDownloadDelegate
- (void)URLSession:(NSURLSession *)session downloadTask:(NSURLSessionDownloadTask *)downloadTask didResumeAtOffset:(int64_t)fileOffset expectedTotalBytes:(int64_t)expectedTotalBytes
{
    
}

/**
 *  这个方法可能被调用多次
 *
 *  @param bytesWritten              这一次下载(写入)的字节数
 *  @param totalBytesWritten         目前已经下载的总字节数
 *  @param totalBytesExpectedToWrite 文件的总字节数
 */
- (void)URLSession:(NSURLSession *)session downloadTask:(NSURLSessionDownloadTask *)downloadTask didWriteData:(int64_t)bytesWritten totalBytesWritten:(int64_t)totalBytesWritten totalBytesExpectedToWrite:(int64_t)totalBytesExpectedToWrite
{
    double progress = (double)totalBytesWritten / totalBytesExpectedToWrite;
    self.progressView.progress = progress;
    NSLog(@"---%f",progress);
}
/**
 *  下载完毕，一般再这里把temp 里面的数据剪切到沙盒中
 *
 *  @param downloadTask 下载任务
 *  @param location     里面有temp的路径
 */
- (void)URLSession:(NSURLSession *)session downloadTask:(NSURLSessionDownloadTask *)downloadTask didFinishDownloadingToURL:(NSURL *)location
{
    // 剪切
    // downloadTask.response.suggestedFilename : 可以通过 downloadTask 获取 response，再通过response 获得推荐名
    NSString *cache = [[NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES)lastObject] stringByAppendingPathComponent:downloadTask.response.suggestedFilename];
    
    // 文件管理这
    NSFileManager *mgr = [NSFileManager defaultManager];
    
    [mgr moveItemAtPath:location.path toPath:cache error:nil];
    NSLog(@"---%@",cache);
}
@end
