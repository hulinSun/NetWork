//
//  ViewController.m
//  15 - 数据加密
//
//  Created by 孙虎林 on 15/8/6.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"
#import "NSString+Hash.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSString *pwd = @"someonelikeu";
    
    NSLog(@"---MD5 加密 %@",[self MD5:pwd]); //  8329ffc20fe1a56366c99a42857c3f1a
    NSLog(@"--doubleMD5-加密 %@",[self doubleMD5:pwd]); // 3c0b1a793b4bfab7252cdaa3eaed1d0b
    NSLog(@"--saltMD5-加密 %@",[self saltMD5:pwd]); //  7cd50688313f7549e7bcfb644b1e5d54
    NSLog(@"--先乱序再加密 -%@",[self MD5Sort:pwd]); //  9ffc20fe1a56366c99a42857c3f1a832
    NSLog(@"--sha--%@",[self sha1:pwd]); // e028f83f13de093e928ef4f28d0da0dab689e591
    
    /**
     *  用户的隐私数据，只有在用户输入那一刻是明文，其他情况都是密文处理
     *  加盐（Salt）：在明文的固定位置插入随机串，然后再进行MD5
     *  先加密，后乱序：先对明文进行MD5，然后对加密得到的MD5串的字符进行乱序
     *  一般公司都有自己的加密方案
     */
}

/**
 *  MD5加密
 */
-(NSString *)MD5:(NSString *)str
{
    return str.md5String;
}

/**
 *  双重MD5 加密
 */
-(NSString *)doubleMD5:(NSString *)str
{
    return str.md5String.md5String;
}

/**
 *  MD5加盐
 */
-(NSString *)saltMD5:(NSString *)str
{
    // 撒盐：随机地往明文中插入任意字符串
    NSString *newStr = [str stringByAppendingString:@"salt"];
    
    return newStr.md5String;
}

/**
 *  先加密，再乱序 (最可靠的方法)
 */
-(NSString *)MD5Sort:(NSString *)str
{
    NSString *newStr = str.md5String; //8329ffc20fe1a56366c99a42857c3f1a
    
    NSString *prefix = [newStr substringFromIndex:3];
    NSString *subfix = [newStr substringToIndex:3];
    
    // 乱序后 result == 9ffc20fe1a56366c99a42857c3f1a832
    NSString *result = [prefix stringByAppendingString:subfix];
    
    return result;
}

-(NSString *)sha1:(NSString *)str
{
    return str.sha1String;
}

@end
