//
//  ViewController.m
//  02 - AFN文件上传
//
//  Created by 孙虎林 on 15/8/7.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"
#import "AFNetworking.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
//    NSLog(@"---%@",NSHomeDirectory());
    
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
//    [self uploadFileData];
    [self uploadFileUrl];
}

/**
 *  文件上传1
 */
-(void)uploadFileData
{
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
#warning 只能放非文件参数
    // 封装参数(这个字典只能放非文件参数)
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"username"] = @"123";
    params[@"age"] = @20;
    params[@"pwd"] = @"456";
    params[@"height"] = @1.55;
    
     // post 请求
    [mgr POST:@"http://localhost:8080/MJServer/upload" parameters:params constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        
        // 这个block 专门用来上传文件的，调用的比下面两个早
      
        /**
         *  appendPartWithFileData: 需要上传的文件的二进制数据
         *  name: 服务器端文件参数名
         *  filename: 上传到服务器的名称
         *  mimeType: 文件类型
         */
        UIImage *img = [UIImage imageNamed:@"0"];
        NSData *data = UIImagePNGRepresentation(img);
        [formData appendPartWithFileData:data name:@"file" fileName:@"mm.png" mimeType:@"image/png"];
        
    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"-请求成功-%@",responseObject);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"--请求失败-%@",error);
    }];
}


/**
 *  文件上传2
 */
-(void)uploadFileUrl
{
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    // 封装参数(这个字典只能放非文件参数)
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"username"] = @"123";
    params[@"age"] = @20;
    params[@"pwd"] = @"456";
    params[@"height"] = @1.55;
    
    // post 请求
    [mgr POST:@"http://localhost:8080/MJServer/upload" parameters:params constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        
        // 这个block 专门用来上传文件的，调用的比下面两个早
        /**
         *  appendPartWithFileURL: 需要上传的文件的URL
         *  name: 服务器端文件参数名
         *  filename: 上传到服务器的名称
         *  mimeType: 文件类型
         */
        
        NSURL *url = [[NSBundle mainBundle]URLForResource:@"0.png" withExtension:nil];
        
        
        [formData appendPartWithFileURL:url name:@"file" fileName:@"xixi.png" mimeType:@"image/png" error:nil];
        
    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"-请求成功-%@",responseObject);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"--请求失败-%@",error);
    }];
}

#warning 下面的方法不能用来做文件上传。容易搞错
//        [formData appendPartWithFormData:<#(NSData *)#> name:<#(NSString *)#>]

@end
