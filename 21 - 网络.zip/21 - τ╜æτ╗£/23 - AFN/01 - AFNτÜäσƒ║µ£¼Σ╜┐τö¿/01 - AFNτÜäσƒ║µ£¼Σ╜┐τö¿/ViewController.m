//
//  ViewController.m
//  01 - AFN的基本使用
//
//  Created by 孙虎林 on 15/8/7.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"
#import "AFNetworking.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    /*
    一、2大管理对象
    1.AFHTTPRequestOperationManager : 对NSURLConnection的封装
    
    2.AFHTTPSessionManager :对NSURLSession的封装
    
    二、AFHTTPRequestOperationManager的具体使用
    1.创建管理者
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    
    2.封装请求参数
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"username"] = @"哈哈哈";
    params[@"pwd"] = @"123";
    
    3.发送请求
    NSString *url = @"http://localhost:8080/MJServer/login";
     
    [mgr POST:url parameters:params
      success:^(AFHTTPRequestOperation *operation, id responseObject) { // 注意这里的真实类型
          // 请求成功的时候调用这个block
          NSLog(@"请求成功---%@", responseObject);
      } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
          // 请求失败的时候调用调用这个block
          NSLog(@"请求失败");
      }];
     
    // GET请求
    [mgr GET:url parameters:params
     success:^(AFHTTPRequestOperation *operation, id responseObject) {
         // 请求成功的时候调用这个block
         NSLog(@"请求成功---%@", responseObject);
     } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
         // 请求失败的时候调用调用这个block
         NSLog(@"请求失败");
     }];
    
    三、对服务器返回数据的解析
    1.AFN可以自动对服务器返回的数据进行解析
    * 默认将服务器返回的数据当做JSON来解析
    
    2.设置对服务器返回数据的解析方式
    1> 当做是JSON来解析（默认做法）
    * mgr.responseSerializer = [AFJSONResponseSerializer serializer];
    * responseObject的类型是NSDictionary或者NSArray
    
    2> 当做是XML来解析
    * mgr.responseSerializer = [AFXMLParserResponseSerializer serializer];
    * responseObject的类型是NSXMLParser
    
    3> 直接返回data
    * 意思是：告诉AFN不要去解析服务器返回的数据，保持原来的data即可
    * mgr.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    3.注意
    * 服务器返回的数据一定要跟responseSerializer对得上
    1> 服务器返回的是JSON数据
    * AFJSONResponseSerializer
    * AFHTTPResponseSerializer
    
    2> 服务器返回的是XML数据
    * AFXMLParserResponseSerializer
    * AFHTTPResponseSerializer
    
    3> 服务器返回的是其他数据
    * AFHTTPResponseSerializer
     
    */
    

}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
//    [self getJSON]; //  get请求，返回的是json 数据
//    [self getXML];
//    [self getData];
//    [self postJSON];
//    [self sessionPost];
    [self testgetJSON];
}


/**
 *  GET 请求，返回json 数据
 */
-(void)getJSON
{
    // 请求操作管理者
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    
    // 封装请求参数 (用字典来封装参数)
    NSMutableDictionary *parame = [NSMutableDictionary dictionary];
    parame[@"username"] = @"123";
    parame[@"pwd"] = @"123";
    
    // 发送get 请求 (默认情况下，返回的id responseObject 对象真实类型是字典，默认返回的是JSON 数据)
    [mgr GET:@"http://localhost:8080/MJServer/login" parameters:parame success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"--请求成功-%@---%@",[responseObject class],responseObject);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"--请求失败 %@-",error);
    }];
}

-(void)testgetJSON
{
    // 请求操作管理者
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    
    // 封装请求参数 (用字典来封装参数)
    NSMutableDictionary *parame = [NSMutableDictionary dictionary];
    parame[@"username"] = @"123";
    parame[@"pwd"] = @"123";
    
    // 发送get 请求 (默认情况下，返回的id responseObject 对象真实类型是字典，默认返回的是JSON 数据)
    [mgr GET:@"http://api.dotaly.com/lol/api/v1/shipin/latest?author=xiaozhi&iap=0&ident=43643E2C-CF06-46E8-9AF2-50A255D268B2&jb=0&limit=50&offset=0&token=7e93a7124b25ee81971b4b2473222c0f" parameters:parame success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"--请求成功-%@---%@",[responseObject class],responseObject);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"--请求失败 %@-",error);
    }];
}

/**
 *  GET 请求，返回XML数据
 */
-(void)getXML
{
    // 请求操作管理者
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    
    // 声明一下表示请求完毕，你返回给我的数据是XML
    mgr.responseSerializer = [AFXMLParserResponseSerializer serializer];
    
    // 封装请求参数 (用字典来封装参数)
    NSMutableDictionary *parame = [NSMutableDictionary dictionary];
    parame[@"username"] = @"123";
    parame[@"pwd"] = @"123";
    parame[@"type"] = @"XML"; // 虽然声明了你给我的是XML 数据，但是你得让服务器知道。所以要告诉服务器返回的数据是XML
    
    [mgr GET:@"http://localhost:8080/MJServer/login" parameters:parame success:^(AFHTTPRequestOperation *operation, NSXMLParser* responseObject) { // 真实类型是NSXMLParser
        // 内部已经封装好了返回的数据给你，所以直接拿到responseObject对象解析就ok了
//        NSXMLParser *responseObject = [[NSXMLParser alloc]initWithData:data];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"--请求失败 %@-",error);
    }];
}

/**
 *  GET请求，返回的是原生的data 数据 :下载的时候一定是要data 的
 */
-(void)getData
{
    // 请求操作管理者
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    
    // 声明一下表示请求完毕，你返回给我的数据原生的数据
    mgr.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    // 封装请求参数 (用字典来封装参数)
    NSMutableDictionary *parame = [NSMutableDictionary dictionary];
    parame[@"username"] = @"123";
    parame[@"pwd"] = @"123";
    
    [mgr GET:@"http://localhost:8080/MJServer/login" parameters:parame success:^(AFHTTPRequestOperation *operation, NSData* responseObject) { // 此时responseObject 真实类型是NSData
//        NSLog(@"----%@",[responseObject class]);
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
        NSLog(@"---%@",dict);
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"--请求失败 %@-",error);
    }];
    
}


#warning  如何利用AFN 发送JSON 数据给服务器
/**
 *  发送post请求，返回json 数据,发送JSON 数据给服务器
 */
-(void)postJSON
{
    // 请求操作管理者
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    
    // 封装请求参数 (用字典来封装参数)
    NSMutableDictionary *parame = [NSMutableDictionary dictionary];

    parame[@"你从哪里来"] = @"我从草原来";
    
    [mgr POST:@"http://localhost:8080/MJServer/order" parameters:parame success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"---请求成功 %@",responseObject);
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"fail");
    }];
}


/**
 *  包装session 发送post 请求
 */
-(void)sessionPost
{
    AFHTTPSessionManager *mgr = [AFHTTPSessionManager manager];
//    mgr.responseSerializer = [AFJSONResponseSerializer serializer];
//    mgr.responseSerializer = [AFXMLParserResponseSerializer serializer]; // 这里的设置通用有用
    
    NSMutableDictionary *parame = [NSMutableDictionary dictionary];
    
    parame[@"username"] = @"123";
    parame[@"pwd"] = @"234";
    
    [mgr POST:@"http://localhost:8080/MJServer/login" parameters:parame success:^(NSURLSessionDataTask *task, id responseObject) {
        NSLog(@"-请求成功-%@-%@---%@",task,responseObject,[responseObject class]); // 字典
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        
        NSLog(@"-请求失败--%@",error);
    }];
    
}


@end
