//
//  ViewController.m
//  03 - 上传图片
//
//  Created by 孙虎林 on 15/8/8.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"
#import "AFNetworking.h"

@interface ViewController ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate>
@property (weak, nonatomic) IBOutlet UIImageView *imgView;

@end

@implementation ViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    self.imgView.contentMode = UIViewContentModeScaleAspectFit;
    
    // 开始监控网络状态
    AFNetworkReachabilityManager *mgr = [AFNetworkReachabilityManager sharedManager];
    [mgr  setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        switch (status) {
            case AFNetworkReachabilityStatusReachableViaWiFi:
                NSLog(@" 用的wifi ");
                break;
                
            case AFNetworkReachabilityStatusReachableViaWWAN:
                NSLog(@" 手机自带网络");
                break;
                
            case AFNetworkReachabilityStatusNotReachable:
                NSLog(@" 没有网络");
                break;
                
            default:
                break;
        }
    }];
    // 开启监控
    [mgr startMonitoring];
    
}

/**
 *  控制器销毁的时候要移除监控
 */
- (void)dealloc
{
    // 移除监控
    [[AFNetworkReachabilityManager sharedManager] stopMonitoring];
}


- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    // 显示alert
    UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:@"请选择操作" message:@"哈哈" preferredStyle:UIAlertControllerStyleActionSheet];
    
    UIAlertAction *camer = [UIAlertAction actionWithTitle:@"照相" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        
        // 判断是否支持照相(只有真机才支持照相)
        if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) return;
        
        // 对应的操作
        UIImagePickerController *pickVC = [[UIImagePickerController alloc]init];
        pickVC.delegate = self;
        
        pickVC.sourceType = UIImagePickerControllerSourceTypeCamera;
        
        [self presentViewController:pickVC animated:YES completion:nil];
        
    }];
    [alertVC addAction:camer];
    
    UIAlertAction *picture = [UIAlertAction actionWithTitle:@"相册" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSLog(@"点击了相册按钮");
        
        // 判断是否支持图片(只有真机才支持照相)
        if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) return;
        
        // 对应的操作
        UIImagePickerController *pickVC = [[UIImagePickerController alloc]init];
        pickVC.delegate = self;
        
        pickVC.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        
        [self presentViewController:pickVC animated:YES completion:nil];
        
    }];
    [alertVC addAction:picture];
    
    UIAlertAction *cancle = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
        NSLog(@"点击了取消按钮");
    }];
    [alertVC addAction:cancle];
    
    [self presentViewController:alertVC animated:YES completion:nil];
}


#pragma mark - UIImagePickerController

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    // 取出图片
    UIImage *img = info[UIImagePickerControllerOriginalImage];
    
    // 退出控制器
    [picker dismissViewControllerAnimated:YES completion:nil];
    
    // 显示图片
    self.imgView.image = img;
    
    
    // 上传图片
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    
    NSMutableDictionary *parame = [NSMutableDictionary dictionary];
    parame[@"username"] = @"孙虎林";
    
    [mgr POST:@"http://192.168.5.2:8080/MJServer/upload" parameters:parame constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        
        NSData *fileData = UIImageJPEGRepresentation(self.imgView.image, 1.0);
        [formData appendPartWithFileData:fileData name:@"file" fileName:@"haha.jpg" mimeType:@"image/jpeg"];
        
    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
        //
        NSLog(@"%@",responseObject);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"---%@",error);
    }];
}


@end
