//
//  AppDelegate.h
//  21 - 压缩与解压缩
//
//  Created by 孙虎林 on 15/8/7.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

