//
//  ViewController.m
//  21 - 压缩与解压缩
//
//  Created by 孙虎林 on 15/8/7.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"
#import "SSZipArchive.h"

#define JNCachePath [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES)lastObject]

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

/**
 *  压缩文件夹
 */
-(void)zipDirect
{
    // 1.表示这个文件夹里面的东西需要解压
    NSString *fileDic = [JNCachePath stringByAppendingPathComponent:@"shl"];
    
    // 2.表示这个路径名，是解压后的文件所在的位置
    NSString *filePaht = [JNCachePath stringByAppendingPathComponent:@"zz.zip"];
    
    // 3.解压的是一个文件夹
    [SSZipArchive createZipFileAtPath:filePaht withContentsOfDirectory:fileDic];
    
}
/**
 *  压缩一些文件
 */
-(void)zipFiles
{
    // 2.表示这个路径名，是解压后的文件所在的位置
    NSString *filePaht = [JNCachePath stringByAppendingPathComponent:@"files.zip"];
    
    // 获取shl 文件夹路径
    NSString *shl = [JNCachePath stringByAppendingPathComponent:@"shl"];
    
    NSString *file1 = [shl stringByAppendingPathComponent:@"minion_01.png"];
    NSString *file2 = [shl stringByAppendingPathComponent:@"minion_02.png"];
    NSString *file3 = [shl stringByAppendingPathComponent:@"minion_03.png"];
    NSString *file4 = [shl stringByAppendingPathComponent:@"minion_15.mp4"];
    NSString *file5 = [shl stringByAppendingPathComponent:@"minion_16.mp4"];
    
    [SSZipArchive createZipFileAtPath:filePaht withFilesAtPaths:@[file1,file2,file3,file4,file5]];
}

/**
 *  解压
 */

-(void)unzip
{
    NSLog(@"---解压");
    // 解压的 压缩文件 路径
    NSString *filePaht = [JNCachePath stringByAppendingPathComponent:@"zz.zip"];
    
    // 解压后的文件存放在文件夹里
    NSString *newshl = [JNCachePath stringByAppendingPathComponent:@"shllll"];
    
    [SSZipArchive unzipFileAtPath:filePaht toDestination:newshl];
    
    
    // 代理方式
//    [SSZipArchive unzipFileAtPath:<#(NSString *)#> toDestination:<#(NSString *)#> delegate:<#(id<SSZipArchiveDelegate>)#>]
    
    // 解压加密
//    [SSZipArchive unzipFileAtPath:<#(NSString *)#> toDestination:<#(NSString *)#> overwrite:<#(BOOL)#> password:<#(NSString *)#> error:<#(NSError *__autoreleasing *)#>]
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
//    [self zipDirect]; // 压缩一个文件夹
//    [self zipFiles]; // 压缩一些文件
//    [self unzip];
}


@end
