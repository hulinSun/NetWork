//
//  ViewController.m
//  12 - 大文件下载（句柄下载）
//
//  Created by 孙虎林 on 15/8/6.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property(nonatomic,strong)NSFileHandle *handle;

@property(nonatomic,assign) long long totalSize;

@property(nonatomic,assign) long long currentSize;

@property(nonatomic,assign,getter=isDownloading) BOOL downloading;


@end

@implementation ViewController

#warning 大文件下载的总之是边下边写，一定要这样才能保证内存无压力

#warning 文件操作
/**
 * NSFileManager *mgr = [NSFileManager defaultManager] 单例
 > NSFileManager的共享对象是线程安全的
 > 定位 创建 拷贝 移动 文件和文件夹。获取 文件或文件夹 属性（大小，修改日期，权限），还可以用来改变 文件和文件夹的属性
 
 >  创建文件夹
 - (BOOL)createDirectoryAtPath:(NSString *)path withIntermediateDirectories:(BOOL)createIntermediates attributes:(NSDictionary *)attributes error:(NSError **)error
 > 创建文件
 - (BOOL)createFileAtPath:(NSString *)path contents:(NSData *)contents attributes:(NSDictionary *)attributes
 
 > 验证文件或文件路径是否存在
 - (BOOL)fileExistsAtPath:(NSString *)path
 
 >  验证文件或路径是否存在，指定是否文件路径
 - (BOOL)fileExistsAtPath:(NSString *)path isDirectory:(BOOL *)isDirectory
 
 
 *  NSFileHandle *handle = [NSFileHandle fileHandleForWritingAtPath:cache];
 >  要给定在那个路径的操作
 >  seekToEndOfFile 追踪到文件的结尾
 >  seekToFileOffset 追踪到文件某一段的位置
 >  writeData 句柄创建是有路径的，意思是就再这个文件里写入数据
 >  closeFile 用完之后就要关闭句柄
 */

- (void)viewDidLoad {
    [super viewDidLoad];
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self downloadHandle];
}

/**
 *  大文件下载：句柄下载(边下边写)
 */
-(void)downloadHandle
{

    if (self.isDownloading == YES) {
        NSLog(@"正在下载，别点了");
        
        return;
    }
    
    // 1.url字符串 转码操作
    NSString *urlStr = [@"http://localhost:8080/MJServer/resources/aa.zip" stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    // 2.创建请求对象
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:urlStr]];
    
    // 发送请求 :类方法
    [NSURLConnection connectionWithRequest:request delegate:self];
    self.downloading = YES;
    
}


/** 开始收到服务器的响应时候调用*/
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    // 获取缓存路径
    NSString *cache = [[NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES)lastObject] stringByAppendingPathComponent:@"haha.zip"];
    NSLog(@"-%@",cache);
    
    // 创建文件管理者
    NSFileManager *mgr = [NSFileManager defaultManager];
    // 创建空的文件
    [mgr createFileAtPath:cache contents:nil attributes:nil];
    
    // 创建句柄对象 : 因为是写入数据，给定那个文件路径
    self.handle = [NSFileHandle fileHandleForWritingAtPath:cache];
    
    self.totalSize = response.expectedContentLength;
    
}

/** 受到服务器返回的数据时候调用(如果数据很大的话，这个方法会调用多次，一般都在这个方法里面拼接data)  */
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    self.currentSize +=(long long)data.length;
    CGFloat progress =1.0 * self.currentSize / self.totalSize;
    NSLog(@"----%.3f%%",progress * 100);
   // 从末尾开始写
    [self.handle seekToEndOfFile];
    
    // 写数据
    [self.handle writeData:data];
    
}

/** 请求结束的时候调用 (一般再这个方法里面 做一些数据的处理) */
-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    // 关闭句柄
    [self.handle closeFile];
    
    // 归零
    self.currentSize = 0;
    self.totalSize= 0;
    
    // 下载完毕，没有再 下载
    self.downloading = NO;
}

@end
