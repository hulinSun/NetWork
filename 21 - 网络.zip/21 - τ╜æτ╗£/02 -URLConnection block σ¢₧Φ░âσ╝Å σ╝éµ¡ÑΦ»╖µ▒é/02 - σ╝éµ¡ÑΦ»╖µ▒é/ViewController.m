//
//  ViewController.m
//  02 - 异步请求
//
//  Created by 孙虎林 on 15/8/4.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    // block 回调的异步请求
    [self asyncConnectionBlock];
}

/**
 *  发送block 回调的异步请求
 */
-(void)asyncConnectionBlock
{
    // 1.url字符串 转码操作
    NSString *urlStr = [@"http://localhost:8080/MJServer/login?username=123&pwd=123" stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    // 2.创建请求对象
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:urlStr]];
    
    
    //    NSOperationQueue *queue = [[NSOperationQueue alloc]init]; // 子线程
    /**
     *  当你传进去的 queue 是主队列的话，那么block回调就在主线程执行操作，解析json 数据刷新ui。
     *  如果不是主队列的话，那么block回调就在异步线程操作。
     */
    
    /** 返回结果的情况
     *  {"error":"密码不正确"}
        {"success":"登录成功"}
        {"error":"用户名不存在"}
     */
    
     // 3.发送网络请求(异步，子线程)
     // 当请求服务器结束之后会自动执行block里面执行的代码（请求成功，请求失败）：data connectionError 两者只有一个有值得
    NSOperationQueue *queue = [NSOperationQueue mainQueue]; // a.回到主线程做的操作
    [NSURLConnection sendAsynchronousRequest:request queue:queue completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
        
        NSLog(@"%ld -- block回调再  线程 %@",data.length,[NSThread currentThread]);
        // 这个block会在请求完毕的时候自动调用
        if (connectionError || data == nil)  return; // 两个都没有值的话，那么请求失败，直接返回
        
        // 解析json 数据
        if (data) { // 有值，那么说明返回数据收到了，
            NSLog(@" 成功受到服务器数据 ");
            // 解析要点： 注意json 数据的根节点是什么，{}:字典 []:数组 “”:字符串
            NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
            NSString *success = dict[@"success"];
            NSLog(@"--%@-%@",success,dict.allKeys[0]);
        }
    }];
}

@end
