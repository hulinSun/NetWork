//
//  ViewController.m
//  07 - POST请求
//
//  Created by 孙虎林 on 15/8/5.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self POST];
}

/**
 *  发送一个post请求
 */
-(void)POST
{
    // urlstr ->转码
    NSString *urlStr = [@"http://localhost:8080/MJServer/login" stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    // url
    NSURL *url = [NSURL URLWithString:urlStr];
    
    // 请求 : 要想法POST请求，必须要用NSMutableURLRequest(可变的)，因为发送的参数信息再请求中设置
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    request.HTTPMethod = @"POST"; // 默认为get.
    
    // 请求参数
    NSString *parame = @"username=123&pwd=1234";
    // str -->data
    NSData *data = [parame dataUsingEncoding:NSUTF8StringEncoding];
    
    // 设置请求体
    request.HTTPBody = data;
    
    // 设置请求超时时间
    request.timeoutInterval = 5.0; // 默认是60s
    
    // 设置请求头信息 (拿到客户端的环境)
    [request setValue:@"iPhone 600" forHTTPHeaderField:@"User-Agent"];

    // 发送请求
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
        
        if (connectionError || data == nil){
#warning 请求超时就会来到这里，这里做一些请求超时的提醒信息
            NSLog(@"请求超时");
            return ;
        }
        
        // 真实类型是 NSHTTPURLResponse ，内部获得状态码，请求头信息
        NSHTTPURLResponse *resp =(NSHTTPURLResponse *)response;
        // 打印响应头
        NSLog(@"---%@",resp.allHeaderFields);
        
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        NSLog(@"%@--%@",dict.allKeys[0],dict.allValues[0]);
    }];
}

/**
 *  POST 请求要点
 *  要设置请求方法为POST(大写)因为默认为GET. request.HTTPMethod = @"POST"
 *  NSMutableURLRequest -> 要用可变请求对象，因为要再请求体中设置参数，并且参数只能用data(dataUsingEncoding)
 *  NSURLResponse *respons 这个对象非常重要
 *  发给服务器的参数全部放在请求体中
 *  设置请求头的信息(客户端的环境) [ setValue: forHTTPHeaderField:@"User-Agent"];
 */

@end
