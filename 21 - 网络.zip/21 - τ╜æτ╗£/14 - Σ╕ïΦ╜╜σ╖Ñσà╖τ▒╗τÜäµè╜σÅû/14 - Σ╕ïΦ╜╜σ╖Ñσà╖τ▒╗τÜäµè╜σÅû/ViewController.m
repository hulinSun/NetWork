//
//  ViewController.m
//  14 - 下载工具类的抽取
//
//  Created by 孙虎林 on 15/8/6.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"
#import "DACircularProgressView.h"
#import "JNDownloadTool.h"

#define JNCachePath [[NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES)lastObject] stringByAppendingPathComponent:@"xixi.zip"]

@interface ViewController ()

@property(nonatomic,weak)DACircularProgressView *circleView;
- (IBAction)download:(id)sender;

@property(nonatomic,strong)JNDownloadTool *downloader;

@end

@implementation ViewController


#warning 注意，懒加载完毕之后一点不要再出现alloc init 再创建了，会出现很多得傻逼问题、 
-(JNDownloadTool *)downloader
{
    if (!_downloader) {
        _downloader = [[JNDownloadTool alloc]init];
        _downloader.downloadUrl = [NSURL URLWithString:@"http://localhost:8080/MJServer/resources/aa.zip"];
        _downloader.destPath = JNCachePath;
        
        _downloader.finishHandle = ^{
            NSLog(@"下载完毕了");
        };
        
        _downloader.errorHandle = ^(NSError *error){
            NSLog(@"---%@",error);
        };
    }
    return _downloader;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    DACircularProgressView *circle = [[DACircularProgressView alloc]init];
    circle.frame = CGRectMake(100, 100, 100, 100);
    [self.view addSubview:circle];
    self.circleView = circle;
    circle.progressTintColor = [UIColor redColor];
    circle.trackTintColor = [UIColor blueColor];
    
    // 传出下载进度，可以监听到下载进度.
    self.downloader.progressHandle = ^(CGFloat progress){
        circle.progress = progress;
    };
    
    NSLog(@"---%@",JNCachePath);
    
}

- (IBAction)download:(UIButton *)btn {
    btn.selected = !btn.isSelected;

    if (self.downloader.isDownloading == YES) { // 正在下载，那么点击一下文字变成暂停。
        [self.downloader pause];
    }else{ // 当前状态为暂停
        [self.downloader start];
    }
}
@end
