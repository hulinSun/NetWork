//
//  JNDownloadTool.m
//  14 - 下载工具类的抽取
//
//  Created by 孙虎林 on 15/8/6.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "JNDownloadTool.h"

@interface JNDownloadTool ()<NSURLConnectionDataDelegate>
/** 文件句柄 */
@property(nonatomic,strong)NSFileHandle *handle;
/** 总共字节数 */
@property(nonatomic,assign) long long totalSize;
/** 当前下载的字节数 */
@property(nonatomic,assign) long long currentSize;
/** 请求连接对象 */
@property(nonatomic,strong)NSURLConnection *conn;

@end

@implementation JNDownloadTool


-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    if (self.errorHandle) {
        self.errorHandle(error); // 传出错误
    }
}

/** 开始收到服务器的响应时候调用*/
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    if (self.totalSize) {
        return;
    }
    
    // 创建文件管理者
    NSFileManager *mgr = [NSFileManager defaultManager];
    // 创建空的文件
    [mgr createFileAtPath:self.destPath contents:nil attributes:nil];
    
    // 创建句柄对象 : 因为是写入数据，给定那个文件路径
    self.handle = [NSFileHandle fileHandleForWritingAtPath:self.destPath];
    
    self.totalSize = response.expectedContentLength;
}

/** 受到服务器返回的数据时候调用(如果数据很大的话，这个方法会调用多次，一般都在这个方法里面拼接data)  */
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    self.currentSize += (long long)data.length;
    
    // 只能用_ 来访问， 毕竟只读
    CGFloat progress =1.0 * self.currentSize / self.totalSize;
    
    if (self.progressHandle) {
        self.progressHandle(progress); // 从内部传值
    }
    
    // 从末尾开始写
    [self.handle seekToEndOfFile];
    // 写数据
    [self.handle writeData:data];
    
}

/** 请求结束的时候调用 (一般再这个方法里面 做一些数据的处理) */
-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    // 关闭句柄
    [self.handle closeFile];
    self.handle = nil;
    // 归零
    self.currentSize = 0;
    self.totalSize= 0;
    
    if (self.finishHandle) {
        self.finishHandle();  // 监听下载完毕
    }
}

/**
 *  开始下载
 */
-(void)start
{
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:self.downloadUrl];
    
    NSString *range = [NSString stringWithFormat:@"bytes=%lld-",self.currentSize];
    
    [request setValue:range forHTTPHeaderField:@"Range"];
    
    // 开始下载
   self.conn =  [NSURLConnection connectionWithRequest:request delegate:self];
    
    _downloading = YES;
}
/**
 *  暂停下载
 */
-(void)pause
{
    [self.conn cancel];
    self.conn = nil;
    _downloading = NO;
}

@end
