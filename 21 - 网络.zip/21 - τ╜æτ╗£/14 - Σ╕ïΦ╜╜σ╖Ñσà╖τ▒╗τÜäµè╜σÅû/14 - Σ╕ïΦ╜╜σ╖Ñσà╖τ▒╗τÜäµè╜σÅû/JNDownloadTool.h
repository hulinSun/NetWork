//
//  JNDownloadTool.h
//  14 - 下载工具类的抽取
//
//  Created by 孙虎林 on 15/8/6.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//  下载工具类的抽取

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface JNDownloadTool : NSObject <NSURLConnectionDataDelegate>

/** 既然我是下载器，那么你给我一个url 我来下载 */
@property(nonatomic,strong)NSURL *downloadUrl;

/** 下载的目标路径 */
@property(nonatomic,copy)NSString *destPath;

/** 提供一个暂停方法给别人来调用 */
- (void)pause;

/** 开始下载(继续下载) */
-(void)start;
/**
 *  标记是否在下载(我封装的东西，不管你的事，别改。证明开发经验。牛逼)
 */
@property (nonatomic,readonly,getter = isDownloading)BOOL downloading;

/**
 *  下载完毕做一点错做
 */
@property(nonatomic,copy)void (^finishHandle)();

/**
 *  监听下载失败 :传值
 */
@property(nonatomic,copy)void (^errorHandle)(NSError *);

/** 监听下载进度 */
@property(nonatomic,copy) void (^progressHandle)(CGFloat );

@end
