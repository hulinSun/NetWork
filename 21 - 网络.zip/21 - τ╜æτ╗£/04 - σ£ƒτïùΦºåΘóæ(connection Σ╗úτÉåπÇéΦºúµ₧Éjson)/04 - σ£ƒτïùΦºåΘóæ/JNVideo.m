//
//  JNVideo.m
//  04 - 土狗视频
//
//  Created by 孙虎林 on 15/8/4.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "JNVideo.h"

@implementation JNVideo

/**
 *   注意： 当你是类方法的时候，那么就不能 有 if (self = [super init]) {} 的判断，
 *   并且最好用self ,为了继承着想
 */
+(instancetype)videoWithDict:(NSDictionary *)dict
{
//    JNVideo *video = [[self alloc]init];
//    
//    video.name = dict[@"name"];
//    video.ID = [dict[@"id"] intValue];
//    video.url = dict[@"url"];
//    video.image = dict[@"image"];
//    video.length = [dict[@"length"] intValue];
//    
//    return video;
    return [[self alloc]initWithDict:dict];
}

- (instancetype)initWithDict:(NSDictionary *)dict
{
    if (self = [super init]) {
        self.name = dict[@"name"];
        self.ID = [dict[@"id"] intValue];
        self.url = dict[@"url"];
        self.image = dict[@"image"];
        self.length = [dict[@"length"] intValue];
    }
    return self;
}

@end
