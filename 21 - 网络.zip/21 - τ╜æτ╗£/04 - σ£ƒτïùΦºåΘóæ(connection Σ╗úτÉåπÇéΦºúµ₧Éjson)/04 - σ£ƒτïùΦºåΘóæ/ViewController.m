//
//  ViewController.m
//  04 - 土狗视频
//
//  Created by 孙虎林 on 15/8/4.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"
#import "JNVideo.h"
#import "JNVideoCell.h"
#import <MediaPlayer/MediaPlayer.h>

@interface ViewController () <UITableViewDataSource,UITableViewDelegate,NSURLConnectionDataDelegate,NSURLConnectionDelegate>
@property(nonatomic,strong)NSData *data;
@property(nonatomic,strong)NSMutableArray *videos;
@end

@implementation ViewController

#pragma mark - lazy
-(NSData *)data
{
    if (!_data) {
#warning data 不可变，为什么赋值之后还有值？
        _data = [[NSData alloc]init];
    }
    return _data;
}

-(NSMutableArray *)videos
{
    if (!_videos) {
        _videos = [[NSMutableArray alloc]init];
    }
    return _videos;
}

- (void)viewDidLoad {
    
    [super viewDidLoad];
    self.tableView.rowHeight = 60;
    
    NSURL *url = [NSURL URLWithString:@"http://localhost:8080/MJServer/video"];
    NSLog(@"%@",NSHomeDirectory());
    
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
     [NSURLConnection connectionWithRequest:request delegate:self];
    
#warning runloop
    // 所以有返回值.将加入制定的runloop中运行。必须保证这是NSURLConnection 不能启动。否则不起作用
//    [conn scheduleInRunLoop:<#(NSRunLoop *)#> forMode:<#(NSString *)#>]
    
    // 将取消再制定的runloop 中运行，会停止NSURLConnection 的运行
//    [conn unscheduleFromRunLoop:<#(NSRunLoop *)#> forMode:<#(NSString *)#>]
}

#pragma mark - UITableView
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.videos.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    JNVideoCell *cell = [JNVideoCell cellWithTableView:tableView];
    
    cell.video = self.videos[indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // 取出模型
    JNVideo *video = self.videos[indexPath.row];
    
#warning 播放器
    // 播放器
    NSString *urlstr = [NSString stringWithFormat:@"http://localhost:8080/MJServer/%@",video.url];
    MPMoviePlayerViewController *playVC = [[MPMoviePlayerViewController alloc]initWithContentURL:[NSURL URLWithString:urlstr]];
    [self presentViewController:playVC animated:YES completion:nil];
    
}
#pragma mark - NSURLConnectionDataDelegate

/** 获得响应 */
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
//    NSLog(@"didReceiveResponse");
}
/** 获得数据 */

#warning  为什么打印再主线程?
/**
 * 解答 ：有两种方法让 NSURLConnection 再子线程中执行
 * 1. block 回调的方法，queue 传 自己创建的子队列
 * 2. 将 NSURLConnection  添加到run loop 中
 *  事实上 NSURLConnection 再主线程中启动的，并非再子线程中启动。但是他具备异步运行的特性。归结于runloop 的作用。
 */
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
     NSLog(@"didReceiveData---%@---%ld",[NSThread currentThread],data.length);
     self.data = data;
}

-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
     NSLog(@"connectionDidFinishLoading");
    
    // 解析
    if (self.data) { // 有值才解析
        NSError *err = nil;
        NSDictionary *dataDict = [NSJSONSerialization JSONObjectWithData:self.data options:NSJSONReadingMutableLeaves error:&err];
        if (err) {
            NSLog(@"解析失败");
        }else{
            NSArray *dictArr = dataDict[@"videos"]; // 里面装的都是字典
            NSMutableArray *tempAr = [NSMutableArray array];
            for (NSDictionary *dict in dictArr) {
                JNVideo *video = [JNVideo videoWithDict:dict];
                [tempAr addObject:video];
            }
            self.videos = tempAr;
            [self.tableView reloadData];
        }
    }
}


@end
