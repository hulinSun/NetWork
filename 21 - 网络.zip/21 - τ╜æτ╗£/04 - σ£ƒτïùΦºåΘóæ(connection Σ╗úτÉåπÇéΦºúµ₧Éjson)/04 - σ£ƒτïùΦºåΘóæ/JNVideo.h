//
//  JNVideo.h
//  04 - 土狗视频
//
//  Created by 孙虎林 on 15/8/4.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 
 {   "id":1,
     "image":"resources/images/minion_01.png",
     "length":10,
     "name":"小黄人 第01部”,
     ”url”:"resources/videos/minion_01.mp4"
 },

 */
@interface JNVideo : NSObject

/** 视频ID */
@property(nonatomic,assign) int ID;
/** 图片名 */
@property(nonatomic,copy)NSString *image;
/** 长度 */
@property(nonatomic,assign) int length;
/** 视频名称 */
@property(nonatomic,copy)NSString *name;
/** 视频路径 */
@property(nonatomic,copy)NSString *url;

+(instancetype)videoWithDict:(NSDictionary *)dict;

-(instancetype)initWithDict:(NSDictionary *)dict;

@end
