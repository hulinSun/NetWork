//
//  JNVideoCell.m
//  04 - 土狗视频
//
//  Created by 孙虎林 on 15/8/4.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "JNVideoCell.h"
#import "JNVideo.h"
#import "UIImageView+WebCache.h"

@implementation JNVideoCell


-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
    }
    return self;
    
}

+(instancetype)cellWithTableView:(UITableView *)tableview
{
    static NSString *ID = @"VIDEo";
    
    JNVideoCell *cell = [tableview dequeueReusableCellWithIdentifier:ID];
    if (!cell) {
        cell = [[JNVideoCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:ID];
    }
    return cell;
}

- (void)setVideo:(JNVideo *)video
{
    _video = video;
    NSString *urlstr = [NSString stringWithFormat:@"http://localhost:8080/MJServer/%@",video.image];
    [self.imageView sd_setImageWithURL:[NSURL URLWithString:urlstr] placeholderImage:[UIImage imageNamed:@"placehoder"]];
    
    self.textLabel.text = video.name;
    self.detailTextLabel.text = [NSString stringWithFormat:@"时长：%d 分钟",video.length];
}
@end
