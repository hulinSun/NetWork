//
//  ViewController.m
//  16 - NSURLSession 简单使用
//
//  Created by 孙虎林 on 15/8/6.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"

#define JNCachePath [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) lastObject]

@interface ViewController () <NSURLSessionDownloadDelegate> // 注意，是下载的代理

@end

@implementation ViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    /**
     *  NSURLSession :[NSURLSession sharedSession] 单例
     *  NSURLSessionDataTask :GET\POST
     *  NSURLSessionDownloadTask : 文件下载
     *  NSURLSessionUploadTask : 文件上传(不常用)
     *  三步走：
     1. 获取session 对象
     2. 获取任务对象 (session 可以通过request，或者url 来发送请求)
     3. [task resume]
     
     *  finishTasksAndInvalidate 完成任务，关闭请求
     *  invalidateAndCancel  取消请求
     */
    
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
//    [self dataTask1];
//    [self dataTask2];
//    [self downloadTask1];
//    [self downloadTask2];
    [self downloadDelegateProgress];
}

/**
 *  发送请求:可以发get 请求，POST请求
 */
-(void)dataTask1
{
    // 获取session 对象
    NSURLSession *session = [NSURLSession sharedSession];
    
    NSURL *url = [NSURL URLWithString:@"http://localhost:8080/MJServer/login?username=123&pwd=123"];
    
//    NSURL *url = [NSURL URLWithString:@"http://localhost:8080/MJServer/resources/images/minion_12.png"];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    
    // 总之要记住，都是通过session对象来发送请求的
    NSURLSessionDataTask *task = [session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) { // 把服务器返回的数据给你，响应头给你
        NSLog(@"-%@-%ld",response,data.length);
    }];
    
    // 恢复任务
    [task resume];
}


/**
 *  请求方式2
 */
-(void)dataTask2
{
    // 获取session 对象
    NSURLSession *session = [NSURLSession sharedSession];
    
    NSURL *url = [NSURL URLWithString:@"http://localhost:8080/MJServer/login?username=123&pwd=123"];
    
   NSURLSessionDataTask *task = [session dataTaskWithURL:url completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSLog(@"-%@-%ld",response,data.length);
    }];
    // 开始请求
    [task resume];
}

/**
 *  下载方式1
 */
-(void)downloadTask1
{
    // 获取session 对象
    NSURLSession *session = [NSURLSession sharedSession];
    
    NSURL *url = [NSURL URLWithString:@"http://localhost:8080/MJServer/resources/aa.zip"];
    
    // 利用url NSURLSessionDownloadTask 来下载数据 (再异步线程中,不会阻塞主线程)
    NSURLSessionDownloadTask *task =  [session downloadTaskWithURL:url completionHandler:^(NSURL *location, NSURLResponse *response, NSError *error) {
        // 文件下载在tmp 路径中: location.path
        
        // response.suggestedFilename ： 建议使用的文件名，一般跟服务器端的文件名一致
        NSString *file = [JNCachePath stringByAppendingPathComponent:response.suggestedFilename];
        
        // 将临时文件剪切或者复制Caches文件夹
        NSFileManager *mgr = [NSFileManager defaultManager];

        // AtPath : 剪切前的文件路径
        // ToPath : 剪切后的文件路径
        [mgr moveItemAtPath:location.path toPath:file error:nil]; // 剪切
    }];
    // 开始任务
    [task resume];
    NSLog(@"---%@",JNCachePath);
}

/**
 *  可以下载大文件，但是，无法监听到下载进度
 */
-(void)downloadTask2
{
    // 获取session 对象
    NSURLSession *session = [NSURLSession sharedSession];
    
    NSURL *url = [NSURL URLWithString:@"http://localhost:8080/MJServer/resources/aa.zip"];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
   NSURLSessionDownloadTask *task = [session downloadTaskWithRequest:request completionHandler:^(NSURL *location, NSURLResponse *response, NSError *error) {
       
       // cache 路径
       NSString *cachePath = [JNCachePath stringByAppendingPathComponent:@"caonima.zip"];
       
       NSFileManager *mgr = [NSFileManager defaultManager];
       
       [mgr moveItemAtPath:location.path toPath:cachePath error:nil];
    }];
    NSLog(@"--%@",JNCachePath);
    [task resume];
}

/**
 *  利用代理的方法来监听下载进度
 */
-(void)downloadDelegateProgress
{
    // 获取配置对象
    NSURLSessionConfiguration *cfg = [NSURLSessionConfiguration defaultSessionConfiguration];
    // 通过配置对象来获取seesion
    NSURLSession *session = [NSURLSession sessionWithConfiguration:cfg delegate:self delegateQueue:[NSOperationQueue mainQueue]];
    
    NSURL *url = [NSURL URLWithString:@"http://localhost:8080/MJServer/resources/aa.zip"];
    // 绑定url
    NSURLSessionDownloadTask *task = [session downloadTaskWithURL:url];
    // 开始任务
    [task resume];
}


#pragma mark ---------------------------------------------------- NSURLSessionDownloadDelegate
/**
*  下载完毕后调用
*  @param location     临时文件的路径（下载好的文件）
*/
- (void)URLSession:(NSURLSession *)session downloadTask:(NSURLSessionDownloadTask *)downloadTask didFinishDownloadingToURL:(NSURL *)location
{
    // location : 临时文件的路径（下载好的文件）
    
    NSString *caches = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) lastObject];
    // response.suggestedFilename ： 建议使用的文件名，一般跟服务器端的文件名一致
    
    NSString *file = [caches stringByAppendingPathComponent:downloadTask.response.suggestedFilename];
    
    // 将临时文件剪切或者复制Caches文件夹
    NSFileManager *mgr = [NSFileManager defaultManager];
    
    // AtPath : 剪切前的文件路径
    // ToPath : 剪切后的文件路径
    [mgr moveItemAtPath:location.path toPath:file error:nil];
}

/**
 *  恢复下载时调用
 */
- (void)URLSession:(NSURLSession *)session downloadTask:(NSURLSessionDownloadTask *)downloadTask didResumeAtOffset:(int64_t)fileOffset expectedTotalBytes:(int64_t)expectedTotalBytes
{
}

/**
 *  每当下载完（写完）一部分时就会调用（可能会被调用多次）
 *  @param bytesWritten              这次调用写了多少
 *  @param totalBytesWritten         累计写了多少长度到沙盒中了
 *  @param totalBytesExpectedToWrite 文件的总长度
 */
- (void)URLSession:(NSURLSession *)session downloadTask:(NSURLSessionDownloadTask *)downloadTask didWriteData:(int64_t)bytesWritten totalBytesWritten:(int64_t)totalBytesWritten totalBytesExpectedToWrite:(int64_t)totalBytesExpectedToWrite
{
    double progress = (double)totalBytesWritten / totalBytesExpectedToWrite;
    NSLog(@"下载进度---%f", progress);
}


@end
