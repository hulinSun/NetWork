//
//  JNVideoTool.m
//  06 - 土狗视频整体优化
//
//  Created by 孙虎林 on 15/8/5.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "JNVideoTool.h"
#import "GDataXMLNode.h"

@interface JNVideoTool ()
@property(nonatomic,strong)NSMutableArray *videos;
@end

@implementation JNVideoTool
JNSingletonM(videoTool);

-(NSMutableArray *)videos
{
    if (!_videos) {
        _videos = [[NSMutableArray alloc]init];
    }
    return _videos;
}

/** JSON 解析 */
-(NSArray *)videosWithJSONData:(NSData *)data
{
    NSMutableArray *tempArr = nil; // 默认为空
    if (data) {
        NSError *err = nil;
        NSDictionary *dataDict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&err];
        if (err) {
            NSLog(@"解析失败");
        }else{ // 成功解析
            NSArray *dictArr = dataDict[@"videos"];
            tempArr = [NSMutableArray array]; // 需要解析的时候才创建
            for (NSDictionary *dict in dictArr) {
                JNVideo *video = [JNVideo videoWithDict:dict];
                [tempArr addObject:video];
            }
        }
    }
    return tempArr;
}

/**DOM 解析XML */
- (NSArray *)domVideosWithXMLData:(NSData *)data
{
    NSMutableArray *tempArr = nil;
    if (data) { // Dom 解析
        //  获取整个XML文档 (dom==》document)
        GDataXMLDocument *doc = [[GDataXMLDocument alloc]initWithData:data options:0 error:nil];
        
        // 获取根元素-- videos
        GDataXMLElement *rootElem = [doc rootElement];
        // 获取子元素 video
        NSArray *elements = [rootElem elementsForName:@"video"];
    
        tempArr = [NSMutableArray array];
        
        // 获取子元素的属性，赋值给模型
        for (GDataXMLElement *element in elements) {
            JNVideo *video = [[JNVideo alloc]init];
            video.ID = [element attributeForName:@"id"].stringValue.intValue;
            video.name = [element attributeForName:@"name"].stringValue;
            video.image = [element attributeForName:@"image"].stringValue;
            video.url = [element attributeForName:@"url"].stringValue;
            video.length = [element attributeForName:@"length"].stringValue.intValue;
            [tempArr addObject:video];
        }
    }
    return tempArr;
}

/**SAX 解析XML */
-(NSArray *)saxVideosWithXMLNData:(NSData *)data
{
    //1.创建解析器
    NSXMLParser *parser = [[NSXMLParser alloc]initWithData:data];
    //2.设置代理: 把解析的结果告诉代理，实际上是代理监听解析的风吹草动
    parser.delegate = self;
    //3.开始解析(事件驱动)
    [parser parse];
    
    return self.videos;
}

#pragma mark - NSXMLParserDelegate
/** 开始解析到文档的时候调用 ：解析开始 */
- (void)parserDidStartDocument:(NSXMLParser *)parser
{
    //    NSLog(@"parserDidStartDocument");
}

/**
 *  开始解析到元素的时候调用
 *
 *  @param parser        解析器对象
 *  @param elementName   元素的名称(这一节点元素的名称)
 *  @param attributeDict 属性字典 (这一节点内属性的 字典,注意，只是解析到的当前节点内的字典)
 */
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
    // 因为节点有多个，所以要判断一下，只需要解析模型对应的节点
    if ([elementName isEqualToString:@"videos"]) return; // 直接返回。不需要创建video 模型
    
    // 能来到这里那么就是video 对应的节点
    JNVideo *video = [JNVideo videoWithDict:attributeDict];
    
    [self.videos addObject:video];
}

/** 结束解析到文档的时候调用 ：解析结束 */
-(void)parserDidEndDocument:(NSXMLParser *)parser
{
}

@end
