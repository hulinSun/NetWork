//
//  JNVideoTool.h
//  06 - 土狗视频整体优化
//
//  Created by 孙虎林 on 15/8/5.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
// 负责解析数据的工具类

#import <Foundation/Foundation.h>
#import "JNSingleton.h"
#import "JNVideo.h"

@interface JNVideoTool : NSObject <NSXMLParserDelegate>
/**
 *  单例宏
 */
JNSingletonH(videoTool);

/**
 *  解析json 数据
 */
-(NSArray *)videosWithJSONData:(NSData *)data;

/**
 *  dom 解析XML数据
 */
-(NSArray *)domVideosWithXMLData:(NSData *)data;
/**
 *  SAX解析xml 数据
 */
-(NSArray *)saxVideosWithXMLNData:(NSData *)data;

@end
