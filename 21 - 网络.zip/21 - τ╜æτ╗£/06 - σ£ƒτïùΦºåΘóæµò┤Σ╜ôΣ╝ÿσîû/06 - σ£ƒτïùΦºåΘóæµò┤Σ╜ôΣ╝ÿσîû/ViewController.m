//
//  ViewController.m
//  06 - 土狗视频整体优化
//
//  Created by 孙虎林 on 15/8/5.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"
#import "JNVideo.h"
#import "JNVideoCell.h"
#import <MediaPlayer/MediaPlayer.h>
#import "JNVideoTool.h"
#import "JNMovieplayerViewController.h"

#define JNVideoUrl(path)  [NSURL URLWithString:[NSString stringWithFormat:@"http://localhost:8080/MJServer/%@",path]]

@interface ViewController ()
@property(nonatomic,strong)NSArray *videos;
@end

@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    self.tableView.rowHeight = 60;
    
    NSURL *url = [NSURL URLWithString:@"http://localhost:8080/MJServer/video?type=XML"];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    // 发送网络请求
    NSOperationQueue *queue = [NSOperationQueue mainQueue];
    
    [NSURLConnection sendAsynchronousRequest:request queue:queue completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
        // 如果有错误，并且没有数据，那么直接返回
        if (connectionError || data == nil) return;
    
        JNVideoTool *tool = [JNVideoTool sharedvideoTool];
        NSArray *arr = [tool saxVideosWithXMLNData:data];
//        NSArray *arr = [tool domVideosWithXMLData:data];
//        NSArray *arr = [tool videosWithJSONData:data];
        self.videos = arr;
        [self.tableView reloadData];
    }];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.videos.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    JNVideoCell *cell = [JNVideoCell cellWithTableView:tableView];
    cell.video = self.videos[indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // 取出模型
    JNVideo *video = self.videos[indexPath.row];
    // 播放器
    NSURL *url = JNVideoUrl(video.url); // 宏的巧妙引用
    JNMovieplayerViewController *playVC = [[JNMovieplayerViewController alloc]initWithContentURL:url];
    [self presentViewController:playVC animated:YES completion:nil];
    
    // 只能全屏播放
    //    MPMoviePlayerController; // 可以随意控制播放器的尺寸
    
}

@end
