//
//  JNMovieplayerViewController.m
//  06 - 土狗视频整体优化
//
//  Created by 孙虎林 on 15/8/5.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "JNMovieplayerViewController.h"

@interface JNMovieplayerViewController ()

@end

@implementation JNMovieplayerViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // 移除程序进入后台的通知
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationDidEnterBackgroundNotification object:nil];
}

#pragma mark - 实现这个方法来控制屏幕方向
/**
 *  控制当前控制器支持哪些方向
 *  返回值是UIInterfaceOrientationMask*
 *  控制了播放器一直是横屏
 */
- (NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskLandscape;
}

@end
