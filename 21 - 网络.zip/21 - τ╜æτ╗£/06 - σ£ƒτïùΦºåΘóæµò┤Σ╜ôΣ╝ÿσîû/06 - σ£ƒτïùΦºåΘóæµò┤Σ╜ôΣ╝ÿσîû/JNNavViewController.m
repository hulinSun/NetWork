//
//  JNNavViewController.m
//  06 - 土狗视频整体优化
//
//  Created by 孙虎林 on 15/8/5.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "JNNavViewController.h"

@interface JNNavViewController ()

@end

@implementation JNNavViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

#pragma mark - 实现这个方法来控制屏幕方向
/**
 *  控制当前控制器(导航栏包装额控制器)支持哪些方向
 *  返回值是UIInterfaceOrientationMask
 */
- (NSUInteger)supportedInterfaceOrientations
{
    /**
     *  UIInterfaceOrientationMaskPortrait : 竖屏(正常)
     *  UIInterfaceOrientationMaskPortraitUpsideDown : 竖屏(上下颠倒)
     *  UIInterfaceOrientationMaskLandscapeLeft : 横屏向左
     *  UIInterfaceOrientationMaskLandscapeRight : 横屏向右
     *  UIInterfaceOrientationMaskLandscape : 横屏(横屏向左\横屏向右)
     *  UIInterfaceOrientationMaskAll : 全部方向(包括上面的所有情况)
     */
    return UIInterfaceOrientationMaskPortrait;
}

@end
