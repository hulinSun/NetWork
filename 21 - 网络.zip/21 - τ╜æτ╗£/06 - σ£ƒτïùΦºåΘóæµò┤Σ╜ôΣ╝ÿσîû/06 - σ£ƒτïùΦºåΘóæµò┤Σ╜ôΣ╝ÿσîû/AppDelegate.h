//
//  AppDelegate.h
//  06 - 土狗视频整体优化
//
//  Created by 孙虎林 on 15/8/5.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

