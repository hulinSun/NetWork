//
//  ViewController.m
//  08 - 发送JSON数据给服务器
//
//  Created by 孙虎林 on 15/8/5.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
  
    
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self sendJSON];
}

/**
 *  发送JSON数据给服务器
 */
-(void)sendJSON
{
    
    NSString *urlStr = [@"http://localhost:8080/MJServer/order" stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    NSURL *url = [NSURL URLWithString:urlStr];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    request.timeoutInterval = 5;
    
    request.HTTPMethod = @"POST";
    
    // JSON 对应的是字典，那么创建字典
    NSDictionary *jsonDict = @{
                               @"你从哪里来":@"我从草原来",
                               @"我抢你什么":@"一百块都不给我",
                               @"我和你什么仇什么冤":@"你是傻逼么",
                               @"以后换个Pro用":@"公司给我配一台就好了",
                               @"微博开放平台账号":@"温柔_半两"
                               };
    
    // dict --> 转data --> 本质还是设置请求体的内容，因为发送数据都是再请求体中(包括参数)
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:jsonDict options:NSJSONWritingPrettyPrinted error:nil];
    
    // 设置请求体
    request.HTTPBody = jsonData;
    
    // 设置请求头内容
    [request setValue:@"iPhone 60" forHTTPHeaderField:@"User-Agent"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"]; // 表明发送的是json 数据
    
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
        if (connectionError ||!data) {
            NSLog(@"请求失败");
            return ;
        }
        
        if (data) {
            NSLog(@"---%@",response);
            NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
            NSLog(@"---%@---%@",dict.allKeys[0],dict.allValues[0]);
        }
    }];
}

@end
