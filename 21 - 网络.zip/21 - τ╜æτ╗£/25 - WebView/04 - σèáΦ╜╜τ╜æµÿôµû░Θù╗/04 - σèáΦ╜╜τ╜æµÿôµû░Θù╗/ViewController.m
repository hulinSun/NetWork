//
//  ViewController.m
//  04 - 加载网易新闻
//
//  Created by 孙虎林 on 15/8/10.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIWebView *webView;

@end

@implementation ViewController



- (void)viewDidLoad {
    [super viewDidLoad];
    
    /**
     *  http://c.m.163.com/nc/article/A7A94MCL00963VRO/full.html
     */
    
    NSString *urlStr = @"http://c.m.163.com/nc/article/A7A94MCL00963VRO/full.html";
    
    NSURL *url = [NSURL URLWithString:urlStr];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
        if (connectionError ||!data) {
            NSLog(@"解析失败");
            return ;
        }
        // 解析json 数据
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        
#warning 这个例子很有价值，一般真正的新闻类开发中，大多通过html 加载网页的。最重要的一点是对新闻返回的json 数据结构了解清楚，一般用模型代替字典来开发
        [self showWebWithDict:dict];
    }];
}

/**
img = [
{
    pixel = 600*342,
    alt = 耍猴人一年之中只在农忙的时候回家，忙完农活又各自外出卖艺。,
    src = http://img3.cache.netease.com/3g/2014/9/29/201409291047472710f.jpg,
    ref = <!--IMG#0-->
}]
 */

/**
 *  给我一个字典，我给你家在一个网页
 */
-(void)showWebWithDict:(NSDictionary *)dict
{
    // 1. 获取新闻数据
    NSDictionary *news = dict[@"A7A94MCL00963VRO"];
    NSLog(@"%@",news);
    
    // 2. 获取body 内容
    NSString *body = news[@"body"];
    
    // 3.获取图片
    NSDictionary *imgs = [news[@"img"] lastObject];
    NSString *imgSrc = imgs[@"src"]; // 获得了图片的url
    NSString *ref = imgs[@"ref"]; // 获取替换的ref
    
    // 图片的html 代码 : 因为是图片，那么一定要有img 标签，不然不会显示的
    NSString *imgHtml = [NSString stringWithFormat:@"<img src=\"%@\" width=\"340\" height=\"171 margin:5px;\">",imgSrc];
    // 4.替换对应的位置,保证图片再哪里，就在那里显示
    NSString *html = [body stringByReplacingOccurrencesOfString:ref withString:imgHtml];
    
    // 5. 获取标题
    NSString *title = news[@"title"];
    // 获取时间
    NSString *ptime = news[@"ptime"];
    // 头部内容
    NSString *header = [NSString stringWithFormat:@"<div class=\"title\">%@</div><div class=\"time\">%@</div>", title, ptime];
    html = [NSString stringWithFormat:@"%@%@", header, html];
    
    // 链接mainBundle中的CSS文件 (可扩展性着想)
    NSURL *cssURL = [[NSBundle mainBundle] URLForResource:@"news" withExtension:@"css"];
    html = [NSString stringWithFormat:@"%@<link rel=\"stylesheet\" href=\"%@\">", html, cssURL];
    
    // 加载网页
    [self.webView loadHTMLString:html baseURL:nil];
}

@end
