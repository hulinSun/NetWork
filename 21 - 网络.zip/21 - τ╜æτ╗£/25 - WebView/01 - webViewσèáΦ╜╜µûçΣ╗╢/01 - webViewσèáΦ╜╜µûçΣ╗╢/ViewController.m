//
//  ViewController.m
//  01 - webView加载文件
//
//  Created by 孙虎林 on 15/8/10.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"

@interface ViewController () <UIWebViewDelegate,UISearchBarDelegate>
@property (weak, nonatomic) IBOutlet UIWebView *webView;

-(IBAction)forward:(id)sender;

-(IBAction)back:(id)sender;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *forBtn;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *backBtn;

@property(nonatomic,weak)UISearchBar *searchbar;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.webView.delegate = self;
    self.webView.scalesPageToFit = YES;
    NSURL *url = [NSURL URLWithString:@"http://www.baidu.com"];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [self.webView loadRequest:request];
    
    // 创建searchbar
    UISearchBar *searchbar = [[UISearchBar alloc]init];
    searchbar.placeholder = @"请输入搜索的内容";
    searchbar.frame = CGRectMake(0, 0, 200, 35);
    self.navigationItem.titleView = searchbar;
    self.searchbar = searchbar;
    searchbar.delegate = self;
    
}


// 前进
-(IBAction)forward:(UIBarButtonItem *)sender;
{
    if ([self.webView canGoForward]) {
        [self.webView goForward];
    }
}

// 回退
-(IBAction)back:(UIBarButtonItem *)sender;
{
    if ([self.webView canGoBack]) {
        [self.webView goBack];
    }
}

#pragma mark - UIWebViewDelegate

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    NSLog(@"加载失败---%@",error);
}

/**
 *  作用：一般用来拦截webView发出的所有请求（加载新的网页）
 *  每当webView即将发送一个请求之前，会先调用这个方法
 *
 *  @param request        即将要发送的请求
 *
 *  @return YES ：允许发送这个请求  NO ：不允许发送这个请求，禁止加载这个请求
 */
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    
    // URL格式：协议头://主机名/路径
    // request.URL.path ： 获得的仅仅是主机名（域名）后面的路径
    // request.URL.absoluteString ： 获得的是一个完整的URL字符串
    
    NSLog(@"----%@",request.URL.absoluteString);
    return YES;
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
//    NSLog(@"网页加载完毕");
    
    self.backBtn.enabled = [self.webView canGoBack];
    self.forBtn.enabled = [self.webView canGoForward];
}

- (void)webViewDidStartLoad:(UIWebView *)webView
{
//    NSLog(@"开始加载网页");
}


#pragma mark - UISearchBarDelegate
// 点击了搜索按钮
-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    NSLog(@"--searchBarSearchButtonClicked-");
    // 点击了searchBar ，那么开始搜索
    if (![searchBar.text hasPrefix:@"http://"]) { // 没有输入http协议头搜索 
        // 转码
        NSString *urlStr = [NSString stringWithFormat:@"http://m.baidu.com/s?word=%@",searchBar.text];
        urlStr = [urlStr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        
        NSURLRequest *req = [NSURLRequest requestWithURL:[NSURL URLWithString:urlStr]];
        
        [self.webView loadRequest:req];
    }
    searchBar.text = nil;
    [searchBar resignFirstResponder];
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    NSLog(@"---%@",searchText);
}

/**
 *  利用webView加载文件
 */
-(void)loadFiles
{
    // 自适应屏幕
    self.webView.scalesPageToFit = YES;
    
    // 百度
    //    NSURL *url = [NSURL URLWithString:@"https://www.baidu.com/index.php?tn=monline_3_dg"];
    
    //    NSURL *url = [[NSBundle mainBundle]URLForResource:@"2 Swift 教程" withExtension:@"pdf"];
    
    //    NSURL *url = [[NSBundle mainBundle]URLForResource:@"08-UIWebView" withExtension:@"pptx"];
    
    NSURL *url = [NSURL URLWithString:@"http://localhost:8080/MJServer/resources/htmls/salary.html"];
    
    
    NSLog(@"---%@",url);
    
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    [self.webView loadRequest:request];
}

@end
