//
//  ViewController.m
//  10 - 小文件下载
//
//  Created by 孙虎林 on 15/8/6.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

/**
 *  下载小文件的方式1
 */
-(void)littleFile1
{
    // 异步下载 --> 不阻塞主线程
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *urlStr = [@"http://localhost:8080/MJServer/resources/images/minion_01.png"  stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        
        NSURL *url = [NSURL URLWithString:urlStr];
        // 下面的代码内部就是发送GET请求。
        NSData *data = [NSData dataWithContentsOfURL:url];
        NSLog(@"---%ld",data.length);
    });
}

/**
 *  小文件下载方法2
 */
-(void)littleFile2
{
    // 效果和上面的方法是一样的
    NSString *urlStr = [@"http://localhost:8080/MJServer/resources/images/minion_01.png"  stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL *url = [NSURL URLWithString:urlStr];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
        // 再这里也能拿到data ，只不过是小文件这样搞
        NSLog(@"--%ld",data.length);
    }];
    
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
//    [self littleFile1];
    [self littleFile2];
}



@end
