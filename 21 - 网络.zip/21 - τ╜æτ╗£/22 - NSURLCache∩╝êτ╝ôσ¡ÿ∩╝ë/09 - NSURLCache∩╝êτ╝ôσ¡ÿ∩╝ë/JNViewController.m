//
//  JNViewController.m
//  09 - NSURLCache（缓存）
//
//  Created by apple on 15-4-20.
//  Copyright (c) 2015年 ___FULLUSERNAME___. All rights reserved.
//

#import "JNViewController.h"

@interface JNViewController ()

@end

@implementation JNViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	
}
/** 只有GET方式才能缓存
 * 缓存： 有硬盘缓存，和内存缓存
 * 顺序：客户端先发送请求给服务器。系统看是是否有内存缓存（程序退出就没有内存缓存了）--->再看硬盘缓存（沙盒里chches）--->服务器端
 * (有缓存，程序没退出)请求--> 内存缓存-->返回
 * (有缓存，程序退出过)请求--> 硬盘缓存--》读取硬盘缓存变为内存缓存---》返回
 * 缓存只能用于不常更新或者一成不变的数据。 一般把上次缓存的时间存起来，设定一个缓存时间，然后更具时间是否更新，但是缓存的不能太多，会越积越多。所以要定时清空缓存
 */
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    // 1.创建请求
    NSString *urlStr = @"http://localhost:8080/MJ/video";
    NSURL *url = [NSURL URLWithString:urlStr];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    
    /**
    NSURLRequestUseProtocolCachePolicy = 0, // 取决于协议，默认没有缓存
    
    NSURLRequestReloadIgnoringLocalCacheData = 1,
    
    NSURLRequestReturnCacheDataElseLoad = 2,// 有缓存就用缓存，没缓存就加在服务器数据
     
    NSURLRequestReturnCacheDataDontLoad = 3,// 有缓存就用缓存，没缓存就当错误处理（离线模式）
     */

    // 2.设置缓存策略
    request.cachePolicy =  NSURLRequestReturnCacheDataElseLoad;
    
    // 根据request拿到缓存，判断时否有缓存
    NSURLCache *cache = [NSURLCache sharedURLCache]; // 是个单例对象
    // 根据请求拿到缓存对象
    NSCachedURLResponse *resp = [cache cachedResponseForRequest:request];
    if (resp) { // 如果存在
        NSLog(@"缓存已经存在");
    }else
    {
        NSLog(@"没有缓存");
    }
    
    // 3.发送请求
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
        if (data) { // 如果data存在。那么解析数据
            NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            NSLog(@"%@",dict);
        }
    }];
    
}

@end
