//
//  JNAppDelegate.h
//  09 - NSURLCache（缓存）
//
//  Created by apple on 15-4-20.
//  Copyright (c) 2015年 ___FULLUSERNAME___. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JNAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
