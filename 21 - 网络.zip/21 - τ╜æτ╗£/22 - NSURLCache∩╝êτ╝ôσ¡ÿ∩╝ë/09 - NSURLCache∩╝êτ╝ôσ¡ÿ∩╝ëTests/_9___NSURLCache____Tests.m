//
//  _9___NSURLCache____Tests.m
//  09 - NSURLCache（缓存）Tests
//
//  Created by apple on 15-4-20.
//  Copyright (c) 2015年 ___FULLUSERNAME___. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface _9___NSURLCache____Tests : XCTestCase

@end

@implementation _9___NSURLCache____Tests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
