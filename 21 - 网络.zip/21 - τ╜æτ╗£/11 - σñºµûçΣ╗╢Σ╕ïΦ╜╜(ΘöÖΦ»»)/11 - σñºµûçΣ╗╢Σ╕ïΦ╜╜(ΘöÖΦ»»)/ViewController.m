//
//  ViewController.m
//  11 - 大文件下载(错误)
//
//  Created by 孙虎林 on 15/8/6.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"
#import "DACircularProgressView.h"

@interface ViewController () <NSURLConnectionDataDelegate>
@property(nonatomic,strong)NSMutableData *fileData;

@property (nonatomic, weak) DACircularProgressView *circleView;

@property(nonatomic,assign) long long totalSize;

@property(nonatomic,strong)UILabel *label;

@end

@implementation ViewController

-(UILabel *)label
{
    if (!_label) {
        _label = [[UILabel alloc]init];
        _label.font = [UIFont systemFontOfSize:15];
        _label.textAlignment = NSTextAlignmentCenter;
        _label.frame = CGRectMake(100, 200, 100, 40);
    }
    
    return _label;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.label];
    
    DACircularProgressView *circleView = [[DACircularProgressView alloc] init];
    circleView.frame = CGRectMake(100, 50, 100, 100);
    circleView.progressTintColor = [UIColor redColor];
    circleView.trackTintColor = [UIColor blueColor];
    [self.view addSubview:circleView];
    self.circleView = circleView;
    
    self.circleView.hidden = YES;
    
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self connectionAsyncDelegte];
}

-(void)connectionAsyncDelegte
{
    // 1.url字符串 转码操作
    NSString *urlStr = [@"http://localhost:8080/MJServer/resources/aa.zip" stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    // 2.创建请求对象
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:urlStr]];
    
    // 发送请求 :类方法
     [NSURLConnection connectionWithRequest:request delegate:self];
    
}

/**
 *  headers {
    "Accept-Ranges" = bytes;
    "Content-Length" = 184459661; 文件大小
    "Content-Type" = "application/zip"; 文件类型
    Date = "Thu, 06 Aug 2015 01:46:51 GMT"; 事件
    Etag = "W/\"184459661-1438824995000\"";
    "Last-Modified" = "Thu, 06 Aug 2015 01:36:35 GMT"; 上次修改
    Server = "Apache-Coyote/1.1"; 服务器
 */

/** 开始收到服务器的响应时候调用*/
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
#warning 虽然打印再主线程，但是他不会阻塞主线程，当textView 滚动的时候，他就停止下载
    // response 里面有很多信息，状态码。请求头
//    NSLog(@"didReceiveResponse--%@-%@",response,[NSThread currentThread]);
    
    // 获取文件的总大小 ：两种方法
//    NSHTTPURLResponse *hprsp = (NSHTTPURLResponse *)response;
//    long long fileSize = [hprsp.allHeaderFields[@"Content-Length"] longLongValue];
//    NSLog(@"%lld",fileSize);
    
    // 期望的文件长度
    long long fileSize = response.expectedContentLength;
    self.totalSize = fileSize;
    
    //   有相应，那么才有必要创建filedata
    self.fileData = [NSMutableData data];
    
}


/** 受到服务器返回的数据时候调用(如果数据很大的话，这个方法会调用多次，一般都在这个方法里面拼接data)  */
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    self.circleView.hidden = NO;
    // 拼接
    [self.fileData appendData:data];
    
     self.circleView.progress = (double)self.fileData.length / self.totalSize;
    
    self.label.text = [NSString stringWithFormat:@"%.2f%%",self.circleView.progress * 100];
  
}

/** 请求结束的时候调用 (一般再这个方法里面 做一些数据的处理) */
-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    // 写入沙盒：大数据不能 方法document，会同步，不会通过审核
    NSString *cache = [[NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES)lastObject] stringByAppendingPathComponent:@"aa.zip"];
    NSLog(@"%@",cache);
    [self.fileData writeToFile:cache atomically:YES];
    
#warning 错误原因： 当数据都下载完毕之后，最后才拼接数据，那么到最后数据累计会很大，再一口气写入沙盒，那么内存有很大压力，很容易崩掉。所以这种方法不合理
}

@end
