//
//  ViewController.m
//  13 - 大文件断点下载
//
//  Created by 孙虎林 on 15/8/6.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"
#import "DACircularProgressView.h"

@interface ViewController ()

@property(nonatomic,strong)NSFileHandle *handle;

@property(nonatomic,assign) long long totalSize;

@property(nonatomic,assign) long long currentSize;

@property(nonatomic,assign,getter=isDownloading) BOOL downloading;
- (IBAction)download:(id)sender;

@property(nonatomic,strong)NSURLConnection *conn;


@property(nonatomic,weak)DACircularProgressView *circleView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    DACircularProgressView *circle = [[DACircularProgressView alloc]init];
    circle.frame = CGRectMake(100, 100, 100, 100);
    [self.view addSubview:circle];
    self.circleView = circle;
    circle.progressTintColor = [UIColor redColor];
    circle.trackTintColor = [UIColor blueColor];
}


/** 开始收到服务器的响应时候调用*/
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    if (self.currentSize)  return; // 说明正在下载
    // 获取缓存路径
    NSString *cache = [[NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES)lastObject] stringByAppendingPathComponent:@"haha.zip"];
    NSLog(@"-%@",cache);
    
    // 创建文件管理者
    NSFileManager *mgr = [NSFileManager defaultManager];
    // 创建空的文件
    [mgr createFileAtPath:cache contents:nil attributes:nil];
    
    // 创建句柄对象 : 因为是写入数据，给定那个文件路径
    self.handle = [NSFileHandle fileHandleForWritingAtPath:cache];
    
    self.totalSize = response.expectedContentLength;
    
}

/** 受到服务器返回的数据时候调用(如果数据很大的话，这个方法会调用多次，一般都在这个方法里面拼接data)  */
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    self.currentSize +=(long long)data.length;
    CGFloat progress =1.0 * self.currentSize / self.totalSize;
    
    self.circleView.progress = progress;
    // 从末尾开始写
    [self.handle seekToEndOfFile];
    // 写数据
    [self.handle writeData:data];
    
}

/** 请求结束的时候调用 (一般再这个方法里面 做一些数据的处理) */
-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    // 关闭句柄
    [self.handle closeFile];
    
    // 归零
    self.currentSize = 0;
    self.totalSize= 0;
}

- (IBAction)download:(UIButton *)btn {
    // 状态取反，调整图片
    btn.selected = !btn.isSelected;
    
    if (btn.isSelected) { // 被选中，显示 || 这正在下载
        
        // 1.url字符串 转码操作
        NSString *urlStr = [@"http://localhost:8080/MJServer/resources/aa.zip" stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        
        // 2.创建请求对象
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:urlStr]];
        // 断点下载，设置请求头,从当前下载的开始下载
        NSString *range = [NSString stringWithFormat:@"bytes=%lld-",self.currentSize];
        
        [request setValue:range forHTTPHeaderField:@"Range"]; // 断点下载
        
        self.conn = [NSURLConnection connectionWithRequest:request delegate:self];
        self.downloading = YES;
        
    }else{ // 暂停下载 conn 对象取消了就要重新创建
        [self.conn cancel];
        self.conn = nil;
    }
}
@end
