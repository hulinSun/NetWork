//
//  ViewController.m
//  01 - 简单的HTTP请求
//
//  Created by 孙虎林 on 15/8/4.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    /**
     接口文档：定义描述服务器端的请求接口
     1> 请求路径URL：客户端应该请求哪个路径
     * http://localhost:8080/MJServer/login?参数名1= &参数名2= ...
     2> 请求参数：客户端要发给服务器的数据
     3> 请求结果：服务器会返回什么东西给客户端
     */
    
    // GET:请求行\请求头(系统默认帮我们搞了。)   （get没有请求体）
#warning url字符串转码操作
    
    // 创建一个URL ： 请求路径   // url一定不能包含中文
    NSString *urlStr = [NSString stringWithFormat:@"http://localhost:8080/MJServer/login?username=%@&pwd=%@",@"123", @"123"];
    // 用添加%来转码，返回一个新的字符串 NSString时不可变的
    urlStr = [urlStr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    NSURL *url = [NSURL URLWithString:urlStr];
    // 创建一个请求  // 创建url请求对象， 一个url请求含有一个url。和请求头，行  NSURLRequest默认GET请求
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    // 发送一个同步请求(在主线程发送请求，没有代理) -> 用法简单，最古老最经典最直接的一种方案
    // 在主线程中发送同步请求，一直等到服务器发送信息。如果服务器反应慢，或者网速不好的话，那么会一直等待数据，会阻塞主线程.这种方法不好，所以大多用异步请求。
    NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    NSLog(@"%ld", data.length);
}

@end
