//
//  ViewController.m
//  11 - 单例模式（MRC）
//
//  Created by 孙虎林 on 15/7/30.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"
#import "JNMusicTool.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    JNMusicTool *music = [JNMusicTool sharedMusicTool];
    JNMusicTool *music2 = [[JNMusicTool alloc]init];
    JNMusicTool *music3 = [music copy];
    [music release];
    [music release];
    NSLog(@"%p----%p----%p",music,music2,music3);
}

@end
