//
//  JNDownloadOperation.m
//  14 - 图片下载原理
//
//  Created by 孙虎林 on 15/8/3.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "JNDownloadOperation.h"

@implementation JNDownloadOperation

/**
 *  当自定义operation添加到队列中，内部会调用这个方法，把内部的操作分装再这个方法里面
 */
- (void)main
{
    @autoreleasepool { // 释放掉子线程中的一些变量(固定写法)
        
        // 因为是自定义operation ，那么线程都是自己掌控,时刻监听操作是否被取消
        if (self.isCancelled) return; // 开始前判断一下
        // 异步下载操作
        NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:self.imgUrl]];
        UIImage *img = [UIImage imageWithData:data];
        
        if (self.isCancelled) return; // 下载完之后判断一下(防止收到内存警告之后还是通知代理)
        
        // 下载完毕，通知代理
        if ([self.delegate respondsToSelector:@selector(downloadOperation:didFinishDownloadImage:)]) {
            [self.delegate downloadOperation:self didFinishDownloadImage:img];
        }
    }
}
@end
