//
//  JNApp.m
//  10 - TableView下载图片
//
//  Created by apple on 15-4-13.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "JNApp.h"

@implementation JNApp

- (instancetype)initWithDict:(NSDictionary *)dict
{
    JNApp *app = [[JNApp alloc]init];
//    app.icon = dict[@"dict"];
//    app.name = dict[@"name"];
//    app.download = dict[@"download"];
    [app setValuesForKeysWithDictionary:dict];
    return app;
}

+(instancetype)appWithDict:(NSDictionary *)dict
{
    return [[self alloc]initWithDict:dict];
}
@end
