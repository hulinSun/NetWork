//
//  JNDownloadOperation.h
//  14 - 图片下载原理
//
//  Created by 孙虎林 on 15/8/3.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <UIKit/UIKit.h>

@class JNDownloadOperation;
@protocol JNDownloadOperationDelegate <NSObject>

@optional
-(void)downloadOperation:(JNDownloadOperation *)downloadOperation didFinishDownloadImage:(UIImage *)img;

@end

@interface JNDownloadOperation : NSOperation
/**
 *  既然是下载的operation ，那么应该有一个url
 */
@property(nonatomic,copy)NSString *imgUrl;

/**
 *  代理属性
 */
@property(nonatomic,weak)id<JNDownloadOperationDelegate> delegate;
/**
 *  那一行
 */
@property(nonatomic,strong)NSIndexPath *indexPath;
@end
