//
//  JNMoneyTool.h
//  10 - 单例模式
//
//  Created by 孙虎林 on 15/7/30.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JNSingleton.h"

@interface JNMoneyTool : NSObject
JNSingletonH(moneyTool);
@end
