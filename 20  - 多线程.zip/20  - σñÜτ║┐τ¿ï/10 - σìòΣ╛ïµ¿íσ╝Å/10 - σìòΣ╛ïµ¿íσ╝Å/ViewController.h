//
//  ViewController.h
//  10 - 单例模式
//
//  Created by 孙虎林 on 15/7/30.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

