//
//  ViewController.m
//  10 - 单例模式
//
//  Created by 孙虎林 on 15/7/30.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "JNMusicTool.h"
#import "ViewController.h"
#import "JNSoundTool.h"
#import "JNDataTool.h"
#import "JNMoneyTool.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    JNMusicTool *tool1 = [[JNMusicTool alloc]init];
//    JNMusicTool *tool2 = [[JNMusicTool alloc]init];
//    JNMusicTool *tool3 = [[JNMusicTool alloc]init];
//    JNMusicTool *tool4 = [tool3 copy];
//    
//    NSLog(@"%p--%p--%p--%p",tool1,tool2,tool3,tool4);
//    JNSoundTool *tool1 = [JNSoundTool sharedSoundTool];
//    JNSoundTool *tool2 = [JNSoundTool sharedSoundTool];
//    JNSoundTool *tool3 = [tool2 copy];
//    NSLog(@"-%p--%p--%p",tool1,tool2,tool3);
    
    JNMoneyTool *tool1 = [JNMoneyTool sharedmoneyTool];
    JNMoneyTool *tool2 = [[JNMoneyTool alloc]init];
    JNMoneyTool *tool3 = [tool2 copy];
    
    NSLog(@"----%p---%p-----%p",tool3,tool2,tool1);
    
    /**
     *  static 关键字作用
     
     *  static 修饰全局变量
     >  会让这个全局变量只在当前的这个文件中能使用，其他文件不能使用。
     >  举例： 单例static ，只在类的.m 文件中声明，别的文件中不能使用修改我的全局变量,如果不加static，那么别人可以拿到我全局变量修改，这样的话就失去了单例的意义
     
     *  static 修饰局部变量
     >  修饰局部变量 :
     >  局部变量的生命周期 跟 全局变量 类似,但是不能改变作用域
     >  能保证局部变量永远只初始化1次，在程序运行过程中，永远只有1分内存
     >  举例： tableview cell 重用中，修饰了局部的ID 变量，这样保证这个ID 只初始化一次，只有一次内存
     */
}


@end
