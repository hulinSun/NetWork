//
//  JNSoundTool.m
//  10 - 单例模式
//
//  Created by 孙虎林 on 15/7/30.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//   饿汉式 ：程序刚启动我就自动给你加载一次

#import "JNSoundTool.h"

@implementation JNSoundTool
static id _instance;

/**
 *  程序刚启动，就把这个类装进内存，就会调用一次,并且只调用一次
 */
+(void)load // 最早调用
{
    // 刚出来就创建
    _instance = [[self alloc]init]; // -->这个方法会来到allocWithZone，然后创建
    NSLog(@"--load--%@",_instance);
}
/**
 *   当第一次使用这个类的时候就会调用
 */
+(void)initialize
{
    NSLog(@"initialize----");
}

+(instancetype)sharedSoundTool
{
    return _instance;
}

+(instancetype)allocWithZone:(struct _NSZone *)zone
{
    // 创建 ,这里不需要加锁，因为刚创建没有多线程
    if (_instance == nil) {
        _instance = [super allocWithZone:zone];
    }
    return _instance;
}

-(id)copyWithZone:(NSZone *)zone
{
    return _instance;
}

@end
