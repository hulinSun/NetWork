//
//  JNDataTool.m
//  10 - 单例模式
//
//  Created by 孙虎林 on 15/7/30.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//  GCD 实现单例

#import "JNDataTool.h"

@implementation JNDataTool

static id _instance;

+(instancetype)allocWithZone:(struct _NSZone *)zone
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance = [super allocWithZone:zone];
    });
    return _instance;
}

+(instancetype)sharedDataTool
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
       _instance = [[self alloc]init];
    });
    return _instance;
}

-(id)copyWithZone:(NSZone *)zone
{
    return _instance;
}
@end
