//
//  JNMusicTool.m
//  10 - 单例模式
//
//  Created by 孙虎林 on 15/7/30.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//   懒汉式 单例

#import "JNMusicTool.h"

@implementation JNMusicTool

/**  首先要创建一个全局的对象
 *   懒汉式 单例，用到我的时候在加载
 *   alloc 内部会调用allocWithZone 方法分配内存空间
 *   copyWithZone 内部会调用这个方法
 *   注意： 加锁前，再外面判断一下是否需要加锁，如果需要如果为空，那么就加锁，里面的判断是否为空。是防止多线程的乱入，防止创建多次
 */

static id _musicTool; // 静态全局对象

+(instancetype)allocWithZone:(struct _NSZone *)zone
{
    if (_musicTool == nil) { // 防止频繁加锁
        @synchronized(self) {
            if (_musicTool == nil) { // 防止创建多次
                _musicTool = [super allocWithZone:zone];
            }
        }
    }
    return _musicTool;

}
+(instancetype)sharedMusicTool
{
    if (_musicTool == nil) { //保证只加一次锁 防止频繁加锁
        @synchronized(self) { // 防止多线程 乱入
            if (_musicTool == nil) { // 防止创建多次
                _musicTool = [[self alloc] init];
            }
        }
    }
    return _musicTool;
}

/**
 *   copy 方法内部会调用这个方法，但copy 有可能会copy 出新的对象
 */
- (id)copyWithZone:(NSZone *)zone
{
    // 是个对象方法，所以已经有对象了，所以，_musicTool 已经有值了
    return _musicTool;
}

@end
