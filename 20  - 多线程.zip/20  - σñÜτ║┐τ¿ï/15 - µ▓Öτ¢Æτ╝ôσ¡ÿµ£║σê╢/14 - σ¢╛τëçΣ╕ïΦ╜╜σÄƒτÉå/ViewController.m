//
//  ViewController.m
//  14 - 图片下载原理
//
//  Created by 孙虎林 on 15/8/3.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"
#import "JNApp.h"

#define  JNAppIconFile(url) [[NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) lastObject] stringByAppendingPathComponent:[url lastPathComponent]]

@interface ViewController ()
/**
 *  存取图片的字典 key：图片url value ：图片
 */
@property(nonatomic,strong)NSMutableDictionary *imgs;
/**
 *  图片下载的操作 key：url value ：下载操作
 */
@property(nonatomic,strong)NSMutableDictionary *operations;

/**
 *  队列
 */
@property(nonatomic,strong)NSOperationQueue *queue;

/**
 *  app 数据
 */
@property(nonatomic,strong)NSArray *apps;


@end

@implementation ViewController
#pragma mark - lazy
// 懒加载
- (NSArray *)apps
{
    if (_apps == nil) {
        // 加载plist
        NSString *path = [[NSBundle mainBundle]pathForResource:@"apps.plist" ofType:nil];
        NSArray *dictArray = [NSArray arrayWithContentsOfFile:path];
        
        NSMutableArray *tempArray = [NSMutableArray array];
        // 字典转模型
        for (NSDictionary *dict in dictArray) {
            JNApp *app = [JNApp appWithDict:dict];
            [tempArray addObject:app];
        }
        _apps = tempArray;
    }
    return _apps;
}

-(NSMutableDictionary *)imgs
{
    if (!_imgs) {
        _imgs = [[NSMutableDictionary alloc]init];
    }
    return _imgs;
}

-(NSOperationQueue *)queue
{
    if (!_queue) {
        _queue = [[NSOperationQueue alloc]init];
    }
    return _queue;
}

-(NSMutableDictionary *)operations
{
    if (!_operations) {
        _operations = [[NSMutableDictionary alloc]init];
    }
    return _operations;
}

#pragma mark - viewDidLoad
- (BOOL)prefersStatusBarHidden
{
    return YES;
}

- (void)viewDidLoad {
    [super viewDidLoad];
}


/**
 *  收到内存警告
 */
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    [self.imgs removeAllObjects];
    [self.operations removeAllObjects];
    [self.queue cancelAllOperations];
}

#pragma mark - tableView
-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.apps.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *ID = @"APP";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:ID];
    }
    // 取出模型
    JNApp *app = self.apps[indexPath.row];
    cell.textLabel.text = app.name;
    cell.detailTextLabel.text = app.download;
    
    // 先从缓存池中去
    UIImage *img = self.imgs[app.icon];
    if (img) { // 有图片，已经下载好了图片
        cell.imageView.image = img;
        NSLog(@"用的内存缓存");
    }else{ // 没有图片，从沙盒中去
#warning 沙盒缓存---> 取
        //  缓存路径 ->带有参数的宏
         NSString *filename = JNAppIconFile(app.icon);
        
        // 取
        NSData *data = [NSData dataWithContentsOfFile:filename];
        if (data) { // 有沙盒缓存
            NSLog(@"用的沙盒缓存");
            cell.imageView.image = [UIImage imageWithData:data];
        }else{ // 没有沙盒缓存，那么显示展位图片，开始下载
            // 显示占位图片
            cell.imageView.image = [UIImage imageNamed:@"placeholder"];
            // 下载图片
            [self downloadImg:app.icon indexPaht:indexPath];
        }
    }
    
//    NSLog(@"---%ld",self.imgs.count);
    return cell;
}

/**
 *  抽取方法
 */
-(void)downloadImg:(NSString *)imgUrl indexPaht:(NSIndexPath *)indexPath
{
    
   __weak typeof(self) weakSelf = self;
    // 取出操作
    NSBlockOperation *opera = self.operations[imgUrl];
    if (opera) { // 正在下载
        // 正在下载什么也不做
    }else{ // 没有下载，那么开启下载
        opera = [NSBlockOperation blockOperationWithBlock:^{
            // 下载
            NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:imgUrl]];
            UIImage *downloadImg = [UIImage imageWithData:data];
            // 回到主线程
            [[NSOperationQueue mainQueue]addOperationWithBlock:^{
                // 下载好了，存图片
                if (downloadImg) { // 有图片才存
                    
                    weakSelf.imgs[imgUrl] = downloadImg;
                    
#warning 沙盒缓存  --> 存
                    // 沙盒文件名: 一个文件名对应一张图片
                    NSString *filename = JNAppIconFile(imgUrl);
//                    NSLog(@"-%@",filename);
                    
                    NSData *data = UIImagePNGRepresentation(downloadImg);
                    
                    // 写入沙盒
                    [data writeToFile:filename atomically:YES];
                }
                // 刷新表格
//                    [self.tableView reloadData];
                [weakSelf.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
                
                // 删除操作->防止操作太多,注意，这是主线程，意味着已经刷新过图片了.
                [weakSelf.operations removeObjectForKey:imgUrl];
            }];
        }];
        // 异步执行
        [self.queue addOperation:opera];
        // 存操作 // 添加到字典中 (这句代码为了解决重复下载)
        self.operations[imgUrl] = opera;
    }
}

/**
 *  下载图片思路
 *  一个图片字典存取图片,key:图片下载地址 value:图片
 *  一个图片字典存取操作， 图片下载的操作 key：url value ：下载操作 -->保证一对一
 *  先从缓存字典里面取图片
 *  有-->显示，没有--> 显示展位图片
 >  没有缓存图片的情况
 >  取出是否有下载操作，有：什么也不做，让他下载 ，没有，那么开启一条操作下载
 >  下载好，保存图片 刷新表格
 >  存操作
 */

/**
 * 缓存机制
 * 只要程序不退出，那么用的就是imgs字典的内存缓存
 * 程序退出，重新运行，用的是 沙盒缓存
 */

/** 存取操作一般写成牛逼的宏
 //  缓存路径
 NSString *cache = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) lastObject];
 
 // 后缀名
 NSString *pathCmt = [imgUrl lastPathComponent];
 
 // 沙盒文件名: 一个文件名对应一张图片
 NSString *filename = [cache stringByAppendingPathComponent:pathCmt];

 */

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    // 暂停下载
    [self.queue setSuspended:YES];
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    // 恢复下载
    [self.queue setSuspended:NO];
}

@end
