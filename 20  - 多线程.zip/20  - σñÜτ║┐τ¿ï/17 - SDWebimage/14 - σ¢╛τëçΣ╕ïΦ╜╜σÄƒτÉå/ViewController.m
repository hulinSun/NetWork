//
//  ViewController.m
//  14 - 图片下载原理
//
//  Created by 孙虎林 on 15/8/3.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"
#import "JNApp.h"


#import "UIImageView+WebCache.h" // 图片下载用的是UIImageView的分类


@interface ViewController ()
/**
 *  app 数据
 */
@property(nonatomic,strong)NSArray *apps;


@end

@implementation ViewController
#pragma mark - lazy
// 懒加载
- (NSArray *)apps
{
    if (_apps == nil) {
        // 加载plist
        NSString *path = [[NSBundle mainBundle]pathForResource:@"apps.plist" ofType:nil];
        NSArray *dictArray = [NSArray arrayWithContentsOfFile:path];
        
        NSMutableArray *tempArray = [NSMutableArray array];
        // 字典转模型
        for (NSDictionary *dict in dictArray) {
            JNApp *app = [JNApp appWithDict:dict];
            [tempArray addObject:app];
        }
        _apps = tempArray;
    }
    return _apps;
}
#pragma mark - viewDidLoad
- (BOOL)prefersStatusBarHidden
{
    return YES;
}

- (void)viewDidLoad {
    [super viewDidLoad];
}


/**
 *  收到内存警告
 */
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - tableView
-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.apps.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *ID = @"APP";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:ID];
    }
    // 取出模型
    JNApp *app = self.apps[indexPath.row];
    cell.textLabel.text = app.name;
    cell.detailTextLabel.text = app.download;
    
    NSURL *url = [NSURL URLWithString:app.icon];
    UIImage *placeHolder = [UIImage imageNamed:@"placeholder"];
    
/***********************************SDWebimage常用方法*****************************************/
    
//    [cell.imageView sd_setImageWithURL:url placeholderImage:placeHolder];
    
//    [cell.imageView sd_setImageWithURL:url placeholderImage:placeHolder completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        // 完成图片加载就会调用
//    }];
    
    // 当用户交互不下载， 下载失败重新下载  SDWebImageProgressiveDownload：一点一滴显示
    SDWebImageOptions option = SDWebImageLowPriority | SDWebImageRetryFailed;
    [cell.imageView sd_setImageWithURL:url placeholderImage:placeHolder options:option progress:^(NSInteger receivedSize, NSInteger expectedSize) {
        // 监听下载进度
    } completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
         // 完成图片加载就会调用
    }];
    return cell;
}

@end
