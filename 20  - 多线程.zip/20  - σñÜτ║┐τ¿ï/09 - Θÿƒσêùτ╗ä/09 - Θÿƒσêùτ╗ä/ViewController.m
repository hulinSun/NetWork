//
//  ViewController.m
//  09 - 队列组
//
//  Created by 孙虎林 on 15/7/30.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imgView;

//@property(nonatomic,strong)UIImage *img1;
//@property(nonatomic,strong)UIImage *img2;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    /**
     *  队列组 创建队列组 ：dispatch_group_create();
     *  dispatch_group_async 将任务放在队列中，将队列放在队列组中，
     *   dispatch_group_notify，唤醒队列。 队列组中的任务都做好了会自动来到这个方法。做一些操作
     */
}



- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    // 1.获取全局的并发队列
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    // 2.创建队列组
    dispatch_group_t group = dispatch_group_create();
    
    __block UIImage *img1 = nil;
    // 3.1将任务放在队列里面，再将队列放在队列组里面
    dispatch_group_async(group, queue, ^{
        NSString *urlStr = @"https://www.baidu.com/img/bd_logo1.png";
        NSURL *url = [NSURL URLWithString:urlStr];
        NSData *data = [NSData dataWithContentsOfURL:url];
        // 再外面修改内部的值，加上__
        img1 = [UIImage imageWithData:data];
        // 当前线程
        NSLog(@"--img1--%@",[NSThread currentThread]);
        
    });
    __block UIImage *img2 = nil;
    // 3.2将任务放在队列里面，再将队列放在队列组里面
    dispatch_group_async(group, queue, ^{
        NSString *urlStr = @"http://a.hiphotos.baidu.com/image/h%3D200/sign=3876d12dc7fdfc03fa78e4b8e43e87a9/b8014a90f603738d59fd2bf1b71bb051f919ecaa.jpg";
        NSURL *url = [NSURL URLWithString:urlStr];
        NSData *data = [NSData dataWithContentsOfURL:url];
        // 再外面修改内部的值，加上__
        img2 = [UIImage imageWithData:data];
        
        
        NSLog(@"--img2--%@",[NSThread currentThread]);
    });
    
    
    // 4.唤醒队列.当队列中的任务都执行完毕之后，会自动来到这个方法，做下一步的操作
    dispatch_group_notify(group, queue, ^{
        
        // 拼接图片
        UIGraphicsBeginImageContextWithOptions(self.imgView.frame.size, NO, 0.0);
        
        // 先话大图片2
        [img2 drawInRect:self.imgView.bounds];
        
        [img1 drawInRect:CGRectMake(100, 300, 100, 44)];
        
        // 获取图片
        UIImage *newImg = UIGraphicsGetImageFromCurrentImageContext();
        
        // 关闭图片上下文
        UIGraphicsEndImageContext();
        
        // 回到主线程
        dispatch_async(dispatch_get_main_queue(), ^{
            self.imgView.image = newImg;
        });
        
    });
}

@end
