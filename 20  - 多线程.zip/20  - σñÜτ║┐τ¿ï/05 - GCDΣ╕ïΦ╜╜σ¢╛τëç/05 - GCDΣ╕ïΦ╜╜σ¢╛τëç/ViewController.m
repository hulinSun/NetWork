//
//  ViewController.m
//  05 - GCD下载图片
//
//  Created by 孙虎林 on 15/7/29.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (strong, nonatomic) IBOutlet UIImageView *imgView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    // 获取系统全局的并发队列
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    
    // 开启异步线程
    dispatch_async(queue, ^{
        NSLog(@"---%@",[NSThread currentThread]);
        // 下载图片
        NSString *urlStr = @"http://img.1985t.com/uploads/attaches/2014/07/18548-RfKtW3.jpg";
        NSURL *url = [NSURL URLWithString:urlStr];
        NSData *data = [NSData dataWithContentsOfURL:url];
        UIImage *img = [UIImage imageWithData:data];
        
        // 回到主线程 最好用一部函数
        dispatch_async(dispatch_get_main_queue(), ^{
            // 主线程
            NSLog(@"-dispatch_get_main_queue--%@",[NSThread currentThread]);
            self.imgView.image = img;
        });
    });
    
}

@end
