//
//  ViewController.m
//  06 - GCD基本使用
//
//  Created by 孙虎林 on 15/7/29.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    /**
     *  GCD要点
     *  两个核心概念：任务(执行什么操作) 和 队列:(用来存放任务)
     *  将任务添加到队列中
     *  GCD会自动将队列中的任务取出，放到对应的线程中执行
     *  任务的取出遵循队列的FIFO原则：先进先出，后进后出
     *  dispatch_async: 异步的方式执行任务, 具备开启线程的能力(一般用来开启子线程)
     *  dispatch_sync :同步的方式执行任务 (不具备开启线程的能力)
     *  并发队列： Concurrent
     >  可以让多个任务并发（同时）执行（自动开启多个线程同时执行任务）
     >  并发功能只有在异步（dispatch_async）函数下才有效

     *  串行队列(Serial)：让任务一个接着一个地执行（一个任务执行完毕后，再执行下一个任务）
     *  容易混淆概念
     >  同步和异步主要影响：能不能开启新的线程
     >  同步：在当前线程中执行任务，不具备开启新线程的能力
     >  异步：在新的线程中执行任务，具备开启新线程的能力
     
     >  并发和串行主要影响：任务的执行方式
     >  并发：多个任务并发（同时）执行
     >  串行：一个任务执行完毕后，再执行下一个任务
     */
}

/**
 * 异步函数 并发队列(最常用)
 * 会开启线程，并且因为是并发队列，所以会开启不止一条线程
 * 任务同时(并发)执行,任务执行没有先后顺序
 */
-(void)asyncGloble
{
    // 并发队列：系统默认自带就有的，不需要自己创建
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    
    dispatch_async(queue, ^{
        NSLog(@"--下载图片1--%@",[NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"---下载图片2--%@",[NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"----下载图片3-%@",[NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"---下载图片4--%@",[NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"----下载图片5-%@",[NSThread currentThread]);
    });
}

/**
 *  异步函数 串行队列 (有时候用)
 *  异步函数会开启线程(因为是串行队列，所以一般只创建一条线程)
 *  任务串行执行
 */
-(void)asyncSerial
{
    // 手动创建串行队列
    dispatch_queue_t queue = dispatch_queue_create("串行队列", NULL);
    
    // 异步函数执行
    dispatch_async(queue, ^{
        NSLog(@"--下载图片1--%@",[NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"---下载图片2--%@",[NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"----下载图片3-%@",[NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"---下载图片4--%@",[NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"----下载图片5-%@",[NSThread currentThread]);
    });
}

/**
 *  异步函数 主队列 --> 相当于再主线程中执行
 *  不开启新的线程
 *  任务串行执行
 */
-(void)asyncMainQueue
{
    /**
     *  主队列： 最特殊的串行队列。和主线程相关的
     */
    
    // 放在主队列中的任务都是再主线程中执行的，并且都是串行执行，并且异步函数就失去了开线程的能力
    dispatch_queue_t queue = dispatch_get_main_queue();
    
    // 异步函数执行
    dispatch_async(queue, ^{
        NSLog(@"--下载图片1--%@",[NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"---下载图片2--%@",[NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"----下载图片3-%@",[NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"---下载图片4--%@",[NSThread currentThread]);
    });
    dispatch_async(queue, ^{
        NSLog(@"----下载图片5-%@",[NSThread currentThread]);
    });
}

/**
 *  同步函数， 主队列 (会出现线程阻塞的状态,不能这么用)
 *  因为是串行，所以我等上面的执行完毕再执行，但是呢，有因为是同步，意味着，不开启线程。你等我执行完了在执行，那么就出现了你等我，我等你， 线程卡死，执行不下去的问题
 */
-(void)synscMainQueue
{
    // 放在主队列中的任务都是再主线程中执行的，并且都是串行执行，并且异步函数就失去了开线程的能力
    dispatch_queue_t queue = dispatch_get_main_queue();
    
    NSLog(@"-----------begin");
    // 异步函数执行
    dispatch_sync(queue, ^{
        NSLog(@"--下载图片1--%@",[NSThread currentThread]);
    });
    dispatch_sync(queue, ^{
        NSLog(@"---下载图片2--%@",[NSThread currentThread]);
    });
    dispatch_sync(queue, ^{
        NSLog(@"----下载图片3-%@",[NSThread currentThread]);
    });
    dispatch_sync(queue, ^{
        NSLog(@"---下载图片4--%@",[NSThread currentThread]);
    });
    dispatch_sync(queue, ^{
        NSLog(@"----下载图片5-%@",[NSThread currentThread]);
    });
    
    NSLog(@"-----------end");
    
}



/**----------------------------下面的不常用--------------------------------------**/

/**
 *  同步函数 串行队列
 *  不会开启线程
 *  任务是串行执行(一个任务执行完毕之后，再执行另一个任务)
 */
-(void)syscSerial
{
    // 串行队列
    dispatch_queue_t serialQ = dispatch_queue_create("串行队列A", NULL);
    
    // 同步函数
    dispatch_sync(serialQ, ^{
        NSLog(@"--下载图片1--%@",[NSThread currentThread]);
    });
    dispatch_sync(serialQ, ^{
        NSLog(@"---下载图片2--%@",[NSThread currentThread]);
    });
    dispatch_sync(serialQ, ^{
        NSLog(@"----下载图片3-%@",[NSThread currentThread]);
    });
    dispatch_sync(serialQ, ^{
        NSLog(@"---下载图片4--%@",[NSThread currentThread]);
    });
    dispatch_sync(serialQ, ^{
        NSLog(@"----下载图片5-%@",[NSThread currentThread]);
    });
}


/**
 *  同步函数  并发队列
 *  不会开启新的线程
 *  并发队列 失去作用(因为是在当前的主线程，主线程逗人串行执行任务的)
 */
-(void)syscGloble
{
    // 并发队列：系统默认自带就有的，不需要自己创建
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    
    dispatch_sync(queue, ^{
        NSLog(@"--下载图片1--%@",[NSThread currentThread]);
    });
    dispatch_sync(queue, ^{
        NSLog(@"---下载图片2--%@",[NSThread currentThread]);
    });
    dispatch_sync(queue, ^{
        NSLog(@"----下载图片3-%@",[NSThread currentThread]);
    });
    dispatch_sync(queue, ^{
        NSLog(@"---下载图片4--%@",[NSThread currentThread]);
    });
    dispatch_sync(queue, ^{
        NSLog(@"----下载图片5-%@",[NSThread currentThread]);
    });
}


- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
//    [self syscSerial];
//    [self syscGloble];
//    [self asyncSerial];
//    [self asyncGloble];
//    [self asyncMainQueue];
    [self synscMainQueue];
}

@end
