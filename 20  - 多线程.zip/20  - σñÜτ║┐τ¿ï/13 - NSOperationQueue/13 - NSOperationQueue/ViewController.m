//
//  ViewController.m
//  13 - NSOperationQueue
//
//  Created by 孙虎林 on 15/7/30.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imgView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    [self operationQueue1];
    
//    self.imgView.contentMode = UIViewContentModeScaleAspectFill;
//    self.imgView.contentMode = UIViewContentModeScaleToFill;
    self.imgView.backgroundColor = [UIColor clearColor];
    self.imgView.contentMode = UIViewContentModeScaleAspectFit;
   
}

/**
 *  简单用法
 */
-(void)operationQueue1
{
    // 1.创建队列
    NSOperationQueue *queue = [[NSOperationQueue alloc]init];
    
    //    queue.suspended
//    queue.maxConcurrentOperationCount 最大并发数(最多能开启几条线程)
//    [queue cancelAllOperations];  取消队列里的所有操作
    
    // 封装操作1
    NSBlockOperation *block1 = [NSBlockOperation blockOperationWithBlock:^{
        NSLog(@"下载图片1 ----block %@",[NSThread currentThread]);
    }];
    
    [block1 addExecutionBlock:^{
        NSLog(@"-excute 再下载一个图片-%@",[NSThread currentThread]);
    }];
    
    // 封装操作2
    NSBlockOperation *block2 = [NSBlockOperation blockOperationWithBlock:^{
        NSLog(@"-I Need AV---%@",[NSThread currentThread]);
    }];
    
    // 添加依赖
    [block2 addDependency:block1]; // 2 依赖于1 ，意味着，1 执行完在执行2
    // 添加到队列中(默认是异步线程)
    [queue addOperation:block1];
    [queue addOperation:block2];
    
    [queue addOperationWithBlock:^{
        NSLog(@"直接开启异步线程,只是拿不到operation 对象操作%@",[NSThread currentThread]);
    }];
}


/**
 *  下载图片线程通信
 */
-(void)downloadImg
{
    // 1.创建队列
    NSOperationQueue *queue = [[NSOperationQueue alloc]init];
   
    [queue addOperationWithBlock:^{
        //下载图片
        NSURL *url = [NSURL URLWithString:@"http://www.33.la/uploads/20130523tpxh/6818.jpg"];
        NSData *data = [NSData dataWithContentsOfURL:url];
        NSLog(@"download---%@",[NSThread currentThread]);
        UIImage *img = [UIImage imageWithData:data]; // 图片
        
        // 回到主线程
       [[NSOperationQueue mainQueue]addOperationWithBlock:^{
           self.imgView.image = img;
           NSLog(@"--mainQueue-%@",[NSThread currentThread]);
       }];
    }];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self downloadImg];
}
@end
