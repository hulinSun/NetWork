//
//  ViewController.m
//  04 - NSThread 线程通信
//
//  Created by 孙虎林 on 15/7/29.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imgView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    /**
     *  线程通信
     *  线程之间传递数据 等
     */
    
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    // 子线程中下载图片-> 后台线程（异步线程） 下载图片
    [self performSelectorInBackground:@selector(download) withObject:nil];
}

/**
 *  子线程中下载图片
 */
-(void)download
{
    NSLog(@"-download--%@",[NSThread currentThread]);
    NSString *urlStr = @"http://img.hb.aicdn.com/1b0bf15516d33054e7e22d4dbfebdebf90fbdb9b7695-55sXod_fw554";
    
    NSURL *url = [NSURL URLWithString:urlStr];
    NSData *data = [NSData dataWithContentsOfURL:url];
    // 下载到的图片
    UIImage *img = [UIImage imageWithData:data];
    
    // 回到主线程 刷新界面--> 传递参数。 等当前线程执行完毕之后再回到主线程
//    [self performSelectorOnMainThread:@selector(downloadFinished:) withObject:img waitUntilDone:YES];
    
    // 代码优化
    [self.imgView performSelectorOnMainThread:@selector(setImage:) withObject:img waitUntilDone:YES];
}

/**
 *  在主线程中执行刷新ui界面
 */
-(void)downloadFinished:(UIImage *)img
{
    NSLog(@"--downloadFinished-%@",[NSThread currentThread]);
    self.imgView.image = img;
}
@end
