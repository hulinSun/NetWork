//
//  ViewController.m
//  01 - 线程阻塞
//
//  Created by 孙虎林 on 15/7/29.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    /**
     *  进程：系统内存中执行的一个应用程序就是一个进程。进程做事情的花要靠线程
     *  主线程处理一些ui刷新事件，点击事件等，所以不能把耗时的操作再主线程中执行
     *  一条线程执行的任务是串行(这条执行完才能执行下一条线程)
     *  开启多条线程可以并行(同时)执行任务
     *  同一时间，cpu只能执行一条线程，那为什么开启多条线程能达到同时执行的效果呢？？
        cpu 再同一时间只执行一条线程，但是，cpu再很短的时间片内切换与不同的线程，所以表面上开起来多线程同时执行
     *  cpu再时间片内的切换--->调度
     *   开启线程的优缺点
     >  优点：提高执行效率，
     >  缺点：线程不能开多，开多条线程的话会 系统内存 占用大，(主线程 1M，子线程 512KB)
     >  cpu 调度的成本高，会出现卡顿的情况
     */
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    for (int i = 0 ; i < 10000; i++) {
        NSLog(@"---%d",i);
    }
}

@end
