//
//  ViewController.m
//  12 - NSBlockOperation
//
//  Created by 孙虎林 on 15/7/30.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    /**
     *  NSOperation
     *  NSOperation 是抽象类，需要用子类来实现一些功能 (NSInvocationOperation 几乎不用)
     *  NSBlockOperation 用block 封装操作，如果封装操作的个数 > 1(addExecutionBlock) ,那么这个操作会自动开启异步线程来执行操作
     *  需要调用start 方法开启 NSOperation可以调用start方法来执行任务，但默认是同步执行的
     *  不管是什么操作，只要将操作放在队列中，默认是异步线程
     */
    
    // Operation封装操作。
    NSBlockOperation *block = [NSBlockOperation blockOperationWithBlock:^{
        NSLog(@"---下载图片-1--%@----",[NSThread currentThread]);
    }];
    
    // 添加操作
    [block addExecutionBlock:^{ //
        NSLog(@"---下载图片--addExecutionBlock-%@----",[NSThread currentThread]);
    }];
    
    [block start];
    // 操作执行完毕的回调
    block.completionBlock = ^{
        NSLog(@"操作执行完毕----");
    };
}
@end
