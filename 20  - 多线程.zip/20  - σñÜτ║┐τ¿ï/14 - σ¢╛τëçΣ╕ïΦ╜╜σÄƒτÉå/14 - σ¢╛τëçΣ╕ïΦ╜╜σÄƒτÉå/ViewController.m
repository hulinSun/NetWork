//
//  ViewController.m
//  14 - 图片下载原理
//
//  Created by 孙虎林 on 15/8/3.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"
#import "JNApp.h"

@interface ViewController ()
/**
 *  存取图片的字典 key：图片url value ：图片
 */
@property(nonatomic,strong)NSMutableDictionary *imgs;
/**
 *  图片下载的操作 key：url value ：下载操作
 */
@property(nonatomic,strong)NSMutableDictionary *operations;

/**
 *  队列
 */
@property(nonatomic,strong)NSOperationQueue *queue;

/**
 *  app 数据
 */
@property(nonatomic,strong)NSArray *apps;


@end

@implementation ViewController
#pragma mark - lazy
// 懒加载
- (NSArray *)apps
{
    if (_apps == nil) {
        // 加载plist
        NSString *path = [[NSBundle mainBundle]pathForResource:@"apps.plist" ofType:nil];
        NSArray *dictArray = [NSArray arrayWithContentsOfFile:path];
        
        NSMutableArray *tempArray = [NSMutableArray array];
        // 字典转模型
        for (NSDictionary *dict in dictArray) {
            JNApp *app = [JNApp appWithDict:dict];
            [tempArray addObject:app];
        }
        _apps = tempArray;
    }
    return _apps;
}

-(NSMutableDictionary *)imgs
{
    if (!_imgs) {
        _imgs = [[NSMutableDictionary alloc]init];
    }
    return _imgs;
}

-(NSOperationQueue *)queue
{
    if (!_queue) {
        _queue = [[NSOperationQueue alloc]init];
    }
    return _queue;
}

-(NSMutableDictionary *)operations
{
    if (!_operations) {
        _operations = [[NSMutableDictionary alloc]init];
    }
    return _operations;
}

#pragma mark - viewDidLoad
- (BOOL)prefersStatusBarHidden
{
    return YES;
}

- (void)viewDidLoad {
    [super viewDidLoad];
}


/**
 *  收到内存警告
 */
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    [self.imgs removeAllObjects];
    [self.operations removeAllObjects];
    [self.queue cancelAllOperations];
}

#pragma mark - tableView
-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.apps.count;
}

#warning 下载好图片就刷新这一行，为什么不通过cell.imageView.image 方法呢？ 因为当下载的过程中，用户偶有滚动，那么正在下载的cell 再缓存池中，给别的cell 用的花，会发生下载两张图片的效果，而下载好立马刷新，（存图片的操作的刷新前面）那么就会被第一宠img循环拦截，所以保证了只下载一次图片


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *ID = @"APP";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:ID];
    }
    // 取出模型
    JNApp *app = self.apps[indexPath.row];
    cell.textLabel.text = app.name;
    cell.detailTextLabel.text = app.download;
    
    // 先从缓存池中去
    UIImage *img = self.imgs[app.icon];
    if (img) { // 有图片，已经下载好了图片
        cell.imageView.image = img;
//        NSLog(@"---从缓存中取--%ld",indexPath.row);
    }else{ // 没有图片，没有下载
        // 显示占位图片
        cell.imageView.image = [UIImage imageNamed:@"placeholder"];
        // 取出操作
        NSBlockOperation *opera = self.operations[app.icon];
        if (opera) { // 正在下载
            // 正在下载什么也不做
        }else{ // 没有下载，那么开启下载
            opera = [NSBlockOperation blockOperationWithBlock:^{
//                NSLog(@"开始下载---%ld",indexPath.row);
                // 下载
                NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:app.icon]];
                UIImage *downloadImg = [UIImage imageWithData:data];
                // 回到主线程
                [[NSOperationQueue mainQueue]addOperationWithBlock:^{
                    // 下载好了，存图片
                    if (downloadImg) { // 有图片才存
                        self.imgs[app.icon] = downloadImg;
                    }
                    // 刷新表格
//                    [self.tableView reloadData];
                    [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
                    
                    // 删除操作->防止操作太多,注意，这是主线程，意味着已经刷新过图片了.
                    [self.operations removeObjectForKey:app.icon];
                }];
            }];
            // 异步执行
            [self.queue addOperation:opera];
            // 存操作 // 添加到字典中 (这句代码为了解决重复下载)
            self.operations[app.icon] = opera;
        }
    }
    
    NSLog(@"-图片个数-----%ld",self.imgs.count);
    return cell;
}

/**
 *  下载图片思路
 *  一个图片字典存取图片,key:图片下载地址 value:图片
 *  一个图片字典存取操作， 图片下载的操作 key：url value ：下载操作 -->保证一对一
 *  先从缓存字典里面取图片
 *  有-->显示，没有--> 显示展位图片
 >  没有缓存图片的情况
 >  取出是否有下载操作，有：什么也不做，让他下载 ，没有，那么开启一条操作下载
 >  下载好，保存图片 刷新表格
 >  存操作
 */

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    // 暂停下载
    [self.queue setSuspended:YES];
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    // 恢复下载
    [self.queue setSuspended:NO];
}

@end
