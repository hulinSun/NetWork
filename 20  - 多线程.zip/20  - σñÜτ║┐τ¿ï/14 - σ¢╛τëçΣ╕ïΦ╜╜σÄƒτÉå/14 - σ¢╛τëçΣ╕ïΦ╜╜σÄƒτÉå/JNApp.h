//
//  JNApp.h
//  10 - TableView下载图片
//
//  Created by apple on 15-4-13.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JNApp : NSObject
/**
 *  应用名称
 */
@property(nonatomic,copy)NSString *name;
/**
 *  应用图片下载地址
 */
@property(nonatomic,copy)NSString *icon;
/**
 *  应用下载数
 */
@property(nonatomic,copy)NSString *download;


// 字典转模型
- (instancetype)initWithDict:(NSDictionary *)dict;
+(instancetype)appWithDict:(NSDictionary *)dict;
@end
