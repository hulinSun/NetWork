//
//  main.m
//  07 - 线程的延迟调用
//
//  Created by 孙虎林 on 15/7/29.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
