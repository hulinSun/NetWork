//
//  ViewController.m
//  07 - 线程的延迟调用
//
//  Created by 孙虎林 on 15/7/29.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"-------touch--");
//    [self performAfter];
    [self GCDAfter];
    
     NSLog(@"-------touchend");
}

-(void)run:(NSString *)obj
{
    NSLog(@"run -%@--%@",obj,[NSThread currentThread]);
}
/**
 *  延迟方式1
 */
-(void)performAfter
{
    
    
    // 三秒之后执行run 方法(不会卡主线程，直接往下走，3s之后再回来执行这个方法)
    [self performSelector:@selector(run:) withObject:@"http://1.png" afterDelay:3];
    
    /**  运行结果：
     *  2015-07-29 19:31:34.735 07 - 线程的延迟调用[3597:1163745] -------touch----
     2015-07-29 19:31:34.736 07 - 线程的延迟调用[3597:1163745] -------touchEnd----
     2015-07-29 19:31:37.737 07 - 线程的延迟调用[3597:1163745] run ---http://1.png
     */

}

/**
 *  延迟方式2
 */
-(void)GCDAfter
{
    // 主队列，那么再主线程中执行
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        NSLog(@"----GCD-task---");
//    });
    
    // 如果是全局队列，那么默认开一条子线程
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSLog(@"---GCD--TASK-%@-",[NSThread currentThread]);
    });
    
}

@end
