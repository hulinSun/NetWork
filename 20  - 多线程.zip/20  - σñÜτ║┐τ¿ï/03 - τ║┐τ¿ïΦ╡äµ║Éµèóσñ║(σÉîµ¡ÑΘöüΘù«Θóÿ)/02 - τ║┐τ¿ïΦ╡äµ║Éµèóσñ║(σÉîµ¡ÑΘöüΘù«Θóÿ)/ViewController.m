//
//  ViewController.m
//  02 - 线程资源抢夺(同步锁问题)
//
//  Created by 孙虎林 on 15/7/29.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

/**
 *   售票员1
 */
@property(nonatomic,strong)NSThread *thread1;
/**
 *   售票员2
 */
@property(nonatomic,strong)NSThread *thread2;
/**
 *   售票员3
 */
@property(nonatomic,strong)NSThread *thread3;
/**
 *  票数
 */
@property(nonatomic,assign) int ticketCount;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 一百张票
    self.ticketCount = 100;
    
    /** 卖票问题 */
    self.thread1 = [[NSThread alloc]initWithTarget:self selector:@selector(sellTicket) object:nil];
    self.thread1.name = @"售票员1";
    self.thread2 = [[NSThread alloc]initWithTarget:self selector:@selector(sellTicket) object:nil];
    self.thread2.name = @"售票员2";
    self.thread3 = [[NSThread alloc]initWithTarget:self selector:@selector(sellTicket) object:nil];
    self.thread3.name = @"售票员3";
    
    /**
     *  加锁的目的：防止资源抢夺出现的问题，代表着，我加了锁，就能保证当前线程执行完毕之后才能允许其他的线程访问资源。
     *  注意加锁的位置： 如果在最外面加锁的话，那么。就只有一个人连续卖票，直到票卖完。及时开了多条线程，也起不到的同步卖票的效果
     *  所以 加锁的准确位置应该在里面访问资源的的时候加锁
     *  加锁的注意点： 加锁只能用同一把锁，必须要用同一把锁，如果锁不同的话，达不到加锁的目睹
     */
}

-(void)sellTicket
{
        while (1) { // 一直卖
            // 卖票
               @synchronized(self){ // 加锁 ：意思是锁住代码，只允许一个线程执行代码
                   
            if (self.ticketCount) { // 有票才开始卖
                [NSThread sleepForTimeInterval:1]; // 休眠一会
                self.ticketCount--;
                NSLog(@"--%@卖了一张票--还剩%d张票",[NSThread currentThread].name,self.ticketCount);
            }else{  // 票卖完了
                [NSThread exit]; // 销毁线程
            }
        } // 解锁
     }
}


- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    // 开始卖票
    [self.thread1 start];
    [self.thread2 start];
    [self.thread3 start];
}

@end
