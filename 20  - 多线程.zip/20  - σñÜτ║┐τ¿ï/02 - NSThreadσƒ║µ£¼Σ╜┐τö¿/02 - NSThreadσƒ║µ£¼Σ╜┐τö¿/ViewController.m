//
//  ViewController.m
//  02 - NSThread基本使用
//
//  Created by 孙虎林 on 15/7/29.
//  Copyright (c) 2015年 孙虎林. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    /**
     *  耗时的操作再子线程中执行，这样就不会阻塞主线程
     */
}

/**
 *  创建线程方式1：创建并开启执行
 */
-(void)creatThread1
{
    // 创建
    NSThread *thread1 = [[NSThread alloc]initWithTarget:self selector:@selector(test:) object:@"线程传参"];
    thread1.name = @"thread1";
    // 开启
    [thread1 start];
}

/**
 *  创建线程方式2：创建就默认执行
 */
-(void)creatThread2
{
    // 无返回值   detach:分离出线程-->创建子线程
   [NSThread detachNewThreadSelector:@selector(test:) toTarget:self withObject:@"创建并执行"];
}

/**
 *  隐式 创建：简单方便，但是不能拿到线程对象
 */
-(void)creatThread3
{
    // 再当前线程中执行某一个方法，相当于直接执行某一个方法
//    [self performSelector:@selector(test:) withObject:@"哈哈"]; ==[self test:@"哈哈"];
    // 5秒后再当前线程中执行某一个方法
//    [self performSelector:@selector(test:) withObject:self afterDelay:5.0];
    
    // 再后台执行(默认开启子线程)
    [self performSelectorInBackground:@selector(test:) withObject:@"background"];
    
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
//    [self creatThread1];
//    [self creatThread2];
//    [self creatThread3];
}


/**
 *  开启线程执行的方法
 *
 *  @param obj 线程中传递过来的参数
 */
-(void)test:(NSString *)obj
{
    for (int i = 0 ; i < 10000; i++) {
        NSLog(@"---%@--%@",obj,[NSThread currentThread]);
    }
}



/**
 *  其他用法
 */
-(void)other
{
    [NSThread currentThread];
    [NSThread isMainThread]; // 当前线程是否在主线程中执行
    [NSThread sleepForTimeInterval:3.0]; // 线程休眠几秒
    [NSThread exit]; // 销毁线程：线程执行完毕之后就会自动消亡
}
@end
